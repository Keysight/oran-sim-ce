import PyLizard
import random

def Vector(data):
    vector = PyLizard.Uint8Vector()
    vector.extend(data)
    return vector

messageChanged = 0
random_UEs=random.sample(range(0,100),5)

def Callback(*args):
    'This will generate 5 random numbers from 0 to 99 and fail the registration for the UEs that have that NGAP ID'
    global messageChanged
    global random_UEs

    if args[0] == 'Transport::SCTP::Receive':
        data = args[1]
        localEndpoint = str(args[2])
        cb = args[3]
        print(localEndpoint)

        if localEndpoint.startswith('20.0.2.10'): # NGRAN
            print('ngran message')
            #print(list(data))
            if list(data)[0] == 0x00 and list(data)[1] == 0x0e and messageChanged < 5: # initial context setup request
                print('[Hook] found initial context setup request ')
                dataList = list(data)
                if dataList[13] in random_UEs:
                    print('Found a UE that will not be registered ')
                    dataList[13] = 0x66   # changing AMF NGAP ID to one outside of the range
                    messageChanged +=1
                    #cb(None)             #either it can be chosen as above to fail register with wrong NGAP ID, or ignore the ICS request
                    cb(Vector(dataList))

PyLizard.SetCallback(Callback)