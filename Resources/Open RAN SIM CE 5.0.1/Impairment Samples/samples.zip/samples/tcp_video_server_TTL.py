import PyLizard
from scapy.all import *
from scapy.contrib.gtp import GTP_U_Header


a = 0 
last_ack =0 
seq_base =0
drop_flag = 0

def Vector(data):
    vector = PyLizard.Uint8Vector()
    vector.extend(data)
    return vector

# Bind the GTPHeader to UDP on port 2152
bind_layers(UDP, GTP_U_Header, dport=2152)

# Helper function to see an example how to access all headers in the packet
def GetAllHeaders(pktHeaders, ipType):
    #print('Raw bytes: %s' % (' '.join(['%02x' % i for i in pktHeaders])))

    if ipType == 0x0800:  # IPv4
        packet = IP(pktHeaders)
    elif ipType == 0x86DD:  # IPv6
        packet = IPv6(pktHeaders)
    else:
        print("Unkonwn IP type: {ipType}")
        return

    #print(packet.show())

    if UDP in packet:
        udpHeader = packet[UDP]

        if udpHeader.dport == 2152:
            gtpHeader = udpHeader[GTP_U_Header]

            if IP in gtpHeader:
                innerIP = gtpHeader[IP]
            elif IPv6 in gtpHeader:
                innerIP = gtpHeader[IPv6]
            else:
                print("Payload is not an IP or IPv6 packet, parsing failed.")
                return

            if UDP in innerIP:
                innerUDPHeader = innerIP[UDP]
            elif TCP in innerIP:
                innerTCPHeader = innerIP[TCP]
            else:
                print("No recognizable payload inside GTP header.")

            # when changing something in inner[*]Header, we need to recompute the checksum by setting innerHeader.chksum = None and calling bytes(innerHeader)

    elif TCP in packet:
        tcpHeader = packet[TCP]
    elif SCTP in packet:
        sctpHeader = packet[SCTP]
    else:
        print("No UDP, TCP, SCTP or GTP found in the packet.")

def Callback(*args):
    if args[0] == 'IxStack::Packet::Send':
        pktHeaders = bytes(args[1])
        ipType = args[2]
        cb = args[3]
        global a
        global last_ack
        global seq_base
        global drop_flag
        #print(ipType)
        # GetAllHeaders(pktHeaders, ipType)

        ### OUTER IP
        if ipType == 0x0800:  # IPv4
            packet = IP(pktHeaders)
            packet.ttl = 10
        elif ipType == 0x86DD:  # IPv6
            packet = IPv6(pktHeaders)
            packet.hlim = 10       
        else:
            print("Unkonwn IP type: {ipType}")
            return

        # print(packet.show())

        # modify TTL
        #packet.ttl = 10

        if UDP in packet:
            udpHeader = packet[UDP]
            #print(udpHeader.show())
            if 'GTP-U Header' in udpHeader:
                innerIP = packet[UDP][GTP_U_Header][IPv6]
                print(innerIP.show())
                ### INNER IP
                if innerIP.version==6:
                    innerIP.hlim = 13
                else:
                    packet.ttl = 12

                


            # modify UDP source port
            #udpHeader.sport = 3000

        cb(Vector(bytes(packet)),False)

PyLizard.SetCallback(Callback)