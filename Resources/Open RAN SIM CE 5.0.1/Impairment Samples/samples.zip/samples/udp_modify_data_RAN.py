import PyLizard


def Vector(data):
    vector = PyLizard.Uint8Vector()
    vector.extend(data)
    return vector
def find_sublist(big_list, small_list):
    indices = []
    sublist_length = len(small_list)
    for i in range(len(big_list) - sublist_length + 1):
        if big_list[i:i + sublist_length] == small_list:
            indices.append(i)
    return indices


echoRequest = False
echoResponse = False
messages = 0


def Callback(*args):
    'This will modify the UDP data inside a GTP message send from RAN by replacing LoadCore with ORANSimCE in the first 10 sent UDP messages'
    global echoRequest, echoResponse, messages

    if args[0] == 'Transport::UDP::Send':
        data = args[1]
        localEndpoint = str(args[2])
        cb = args[3]
        # Replace with GNB N3 address
        if localEndpoint.startswith('20.0.3.10'):  # packet sent by GNB.
            # Found a message sent from GNB N3 IP address
            if messages < 10:
                messages += 1
                dataList=list(data)
                indices= find_sublist(dataList,[76, 111, 97, 100, 67, 111, 114, 101])   # looked for LoadCore string in the UDP data
                first=indices[0]       # we will only replace the 1st iteration of LoadCore string
                print(indices)
                dataList2= dataList[:first] + [79, 82, 65, 78, 83, 105, 109, 67, 69] + dataList[first+8:] # replaced LoadCore string with ORANSimCE
                print(dataList2)
                cb(Vector(dataList2))
            else:
                print("No need to modify further messages")


PyLizard.SetCallback(Callback)
