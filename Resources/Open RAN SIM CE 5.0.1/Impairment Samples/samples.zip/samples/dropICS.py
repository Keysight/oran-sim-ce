import PyLizard

def Vector(data):
    vector = PyLizard.Uint8Vector()
    vector.extend(data)
    return vector

messageChanged = 0

def Callback(*args):
    'This will the first ICS message and fail the registration. If retries is enabled, registration will succeed on 1st retry'
    global messageChanged

    if args[0] == 'Transport::SCTP::Receive':
        data = args[1]
        localEndpoint = str(args[2])
        cb = args[3]
        print(localEndpoint)

        if localEndpoint.startswith('20.0.2.10'): # NGRAN
            print('ngran message')
            print(list(data))
            if list(data)[0] == 0x00 and list(data)[1] == 0x0e and messageChanged == 0: # initial context setup request
                print('[Hook] found the first initial context setup request ')
                messageChanged +=1
                cb(None)

PyLizard.SetCallback(Callback)