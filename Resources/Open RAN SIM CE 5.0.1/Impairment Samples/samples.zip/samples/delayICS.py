import PyLizard
import time

def Vector(data):
    vector = PyLizard.Uint8Vector()
    vector.extend(data)
    return vector

messageChanged = 0

def Callback(*args):
    'This will delay the next message after Authentication request by half a second'
    global messageChanged

    if args[0] == 'Transport::SCTP::Receive':
        data = args[1]
        localEndpoint = str(args[2])
        cb = args[3]
        print(localEndpoint)

        if localEndpoint.startswith('20.0.2.10'): # NGRAN
            print('ngran message')
            print(list(data))
            if list(data)[0] == 0x00 and list(data)[1] == 0x04 and messageChanged == 0: # Auth request
                print('[Hook] found the first downlinkNASTransport/Auth Request ')
                dataList = list(data)
                time.sleep(0.5)
                messageChanged +=1
                cb(Vector(dataList))

PyLizard.SetCallback(Callback)