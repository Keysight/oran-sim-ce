$(document).ready(function () {
    var tabletMobileMediaQuery = window.matchMedia("(max-width: 1280px)"); // Adjust the breakpoint as needed

    function updateButtonStatus() {
        if (tabletMobileMediaQuery.matches) {
            $("button.toggle-toc-off-button, button.toggle-toc-on-button").hide();
            $(".sidenav-wrapper").hide();
        } else {
            $("button.toggle-toc-off-button").show();
            $("button.toggle-toc-on-button").hide();
            $(".sidenav-wrapper").show();
        }
    }

    updateButtonStatus(); // Call the function initially to set the initial button status

    tabletMobileMediaQuery.addListener(updateButtonStatus); // Listen for changes in screen width

    $("button.toggle-toc-off-button").on("click touch", function () {
        if (!tabletMobileMediaQuery.matches) {
            $("button.toggle-toc-on-button").show();
            $(this).hide();
            $(".sidenav-wrapper").toggle();
        }
    });

    $("button.toggle-toc-on-button").on("click touch", function () {
        if (!tabletMobileMediaQuery.matches) {
            $(this).hide();
            $("button.toggle-toc-off-button").show();
            $(".sidenav-wrapper").toggle();
        }
    });
});
