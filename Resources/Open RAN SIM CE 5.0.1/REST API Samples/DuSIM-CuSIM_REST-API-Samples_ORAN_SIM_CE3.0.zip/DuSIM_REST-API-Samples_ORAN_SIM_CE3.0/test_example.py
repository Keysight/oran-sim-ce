#!/usr/bin/python3
import unittest
import time
import sys, os
from pprint import pformat
sys.path.insert(1, '..//')
sys.path.insert(1, '../')
from base import TestCaseRemote, Utils
import lib.softassert


class TestMW(TestCaseRemote, lib.softassert.TestCase):

    def __init__(self, *args, **kwargs):
        super(TestMW, self).__init__(*args, **kwargs)
        self.clusterIP = "10.39.32.145"  # UI/MW ip address
        self.Agent1 = "10.39.33.81"  # agent1 ip address used for DUCP & DUUP
        self.Agent2 = "10.39.32.93"  # agent2 ip address used for CUCP & CUUP
        self.licenseServer = "10.38.159.144"  # license server
        self.username = 'admin'
        self.password = 'admin'


    def test_dusim_cusim_b2b(self):
        self.mw = self.newMW(self.clusterIP, self.port1, protocol='https', enablehttp2=False)     # create a mw object

        # configure DuSIM
        #############################################################
        agentsDict = {}
        # define how to map the agents
        agentsDict['ducp'] = [{'agent': self.Agent1, 'F1': 'ens160', 'Kin': 'ens160'}]
        agentsDict['duup'] = [{'agent': self.Agent1, 'F1': 'ens192', 'Kin': 'ens160'}]


        configName = "configs/linux_DUSIM_1UERANGE_10UE_1DU_1CELL_CPlane.zip" # config name found in configs folder
        SessionID = self.mw.newSession(configArchive=configName)  # start session using the specified config

        # assign agent based on the dict
        self.mw.assignAgents(SessionID, agentsDict)
        #self.mw.patchNetworkSettings(SessionID, self.Agent1, 'ens192', networkStack="ixStack")
        self.mw.patchNetworkSettings(SessionID, self.Agent1, 'ens160', capture=True)

        # configure CuSIM
        #############################################################
        agentsDictCU = {}
        # define how to map the agents
        agentsDictCU['cucp'] = [{'agent': self.Agent2, 'F1': 'ens160', 'Kin': 'ens160'}]
        agentsDictCU['cuup'] = [{'agent': self.Agent2, 'F1': 'ens192', 'Kin': 'ens160'}]

        configName = "configs/linux_CUSIM_1UERANGE_10UE_1CU_1CELL_CPlane.zip" # config name found in configs folder
        SessionIDCU = self.mw.newSession(configArchive=configName)  # start session using the specified config
        self.mw.assignAgents(SessionIDCU, agentsDictCU)
        
        # Start CuSIM
        #############################################################
        self.mw.startTest(SessionIDCU)
        sessionState = self.mw.checkSessionState(SessionIDCU, status='STARTED', waitTime=30)

        if sessionState == False:
            self.assertEqual(sessionState, True, 'CuSIM Test failed to start')  # check if test started

        # Start DuSIM
        #############################################################
        self.mw.startTest(SessionID, wait=240)

        sessionState = self.mw.checkSessionState(SessionID, status='STARTED', waitTime=40)

        if sessionState == False:
            self.mw.stopTest(SessionIDCU, wait=180)
            self.assertEqual(sessionState, True, 'DuSIM Test failed to start within 240s ')  # check if test started

        # leave the test to run 60seconds. Remove this when the test stops after the test duration elapsed
        time.sleep(60)

        self.mw.stopTest(SessionID, wait=400)
        self.mw.stopTest(SessionIDCU, wait=400)
        sessionState = self.mw.checkSessionState(SessionID, status='STOPPED', waitTime=60)

        if sessionState == False:
            self.assertEqual(sessionState, True, 'DuSIM Test failed to stop')  # check if test stopped


        Dusimoverview_F1Setup = self.mw.getStats('Dusimoverview_F1Setup', SessionID)
        self.soft_assert(self.assertEqual,max(Dusimoverview_F1Setup['F1 Setup Initiated']), 1)
        self.soft_assert(self.assertEqual,max(Dusimoverview_F1Setup['F1 Setup Initiated']), max(Dusimoverview_F1Setup['F1 Setup Succeeded']))
        self.soft_assert(self.assertEqual,max(Dusimoverview_F1Setup['F1 Setup Failed']), 0)

        # assert_all stats from above. This is used to compare all the stats before exiting the test
        self.assert_all(debug=self.debug)


if __name__ == '__main__':
    unittest.main()

