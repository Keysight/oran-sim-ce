import unittest
import threading

import os
import time
import csv
import zipfile

import requests
from requests.exceptions import ConnectionError
import logging
from pprint import pformat
import sys
import json
import shutil

import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

from hyper.contrib import HTTP20Adapter

logFileName = 'rest-tests-output.log' # need to change this
licenseServer = "10.38.159.144"

# def inDocker():
#     return os.path.isfile('/.dockerenv')

class _TestCaseBase(unittest.TestCase):
    @staticmethod
    def setUpProp(obj):
        if obj.setupFailed:
            obj.fail('Test case setup failed')
            return
        obj.logger.info('==========================================================')
        obj.logger.info('Setting up test "%s"...' % obj._testMethodName)
        if not obj.singleInstance:
            obj.assertTrue(obj.lizard.start())
        if obj.lizard:
            obj.lizard.setTestcase(obj)

    @staticmethod
    def tearDownProp(obj):
        obj.logger.info('Tearing down test "%s"...' % obj._testMethodName)
        if obj.lizard:
            obj.lizard.setTestcase(None)
        if not obj.singleInstance:
            obj.lizard.stop()
            obj.logger.info('Test complete')

    def setUp(self):
        _TestCaseBase.setUpProp(self)

    def tearDown(self):
        _TestCaseBase.tearDownProp(self)

    extra_msg = None

    def assertEquals(self, left, right):
        if self.extra_msg != None:
            unittest.TestCase.assertEquals(self, left, right, "%s != %s (%s) " % (str(left), str(right), self.extra_msg))
        else:
            unittest.TestCase.assertEquals(self, left, right)

    def assertType(self, var, _type):
        self.assertEquals(type(var), _type)

    def assertEmpty(self, arg):
        self.assertEquals(len(arg), 0)

    def assertStatus(self, code, response):
        self.assertEquals(response.status_code, code)

class TestCaseRemote(_TestCaseBase):
    @staticmethod
    def setUpClassProp(obj):
        obj.logger = None
        obj.logLevel = logging.DEBUG # logLevel for file logger
        obj.lizard = None
        obj.singleInstance = True
        obj.setupFailed = False
        obj.logger = logging.getLogger(logFileName)
        
        # Create a custom logger
        # enable file logger
        logging.basicConfig(filename=logFileName, format='%(asctime)s - %(levelname)s - %(message)s', datefmt='%m/%d/%Y %I:%M:%S %p', level=obj.logLevel)

        # create logger for stdout
        obj.stdout_handler = logging.StreamHandler(sys.stdout)
        formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s', datefmt='%m/%d/%Y %I:%M:%S %p')
        obj.stdout_handler.setFormatter(formatter)
        obj.stdout_handler.setLevel(logging.INFO)   # stdout logger level
        obj.logger.addHandler(obj.stdout_handler)


        # Make logger also output to STDOUT in some cases
        if obj.logLevel == logging.WARNING:
            handler = logging.StreamHandler(sys.stdout)
            handler.setLevel(logging.ERROR)
            formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
            handler.setFormatter(formatter)
            obj.logger.addHandler(handler)

        obj.logger.debug('Setting up remote test case "%s"...' % obj.__name__)

    @staticmethod
    def tearDownClassProp(obj):
        obj.logger.debug('Tearing down remote test case "%s"...' % obj.__name__)
        obj.logger.info('Test case complete')
        # close stdout_handler after each island
        obj.stdout_handler.close()
        obj.logger.removeHandler(obj.stdout_handler)

    @classmethod
    def setUpClass(cls):
        TestCaseRemote.setUpClassProp(cls)

    @classmethod
    def tearDownClass(cls):
        TestCaseRemote.tearDownClassProp(cls)

    def newMW(self, host, port, protocol='https', enablehttp2=True, licenseServer=licenseServer):
        return MW(self.logger, self, host, port, protocol, enablehttp2, licenseServer)

    def newAgent(self, host, port, protocol='https', enablehttp2=True):
        return LizardAgent(self.logger, self, host, port, protocol, enablehttp2)

class TestCaseRemoteRegression(_TestCaseBase):
    @staticmethod
    def setUpClassProp(obj):
        obj.logger = None
        obj.logLevel = logging.DEBUG # logLevel for file logger
        obj.lizard = None
        obj.singleInstance = True
        obj.setupFailed = False
        obj.logger = logging.getLogger(logFileName)
        
        # Create a custom logger
        # enable file logger
        logging.basicConfig(filename=logFileName, format='%(asctime)s - %(levelname)s - %(message)s', datefmt='%m/%d/%Y %I:%M:%S %p', level=obj.logLevel)

        obj.logger.debug('Setting up remote test case "%s"...' % obj.__name__)

    @staticmethod
    def tearDownClassProp(obj):
        obj.logger.debug('Tearing down remote test case "%s"...' % obj.__name__)
        obj.logger.info('Test case complete')
        # close stdout_handler after each island

    @classmethod
    def setUpClass(cls):
        TestCaseRemoteRegression.setUpClassProp(cls)

    @classmethod
    def tearDownClass(cls):
        TestCaseRemoteRegression.tearDownClassProp(cls)

    def newMW(self, host, port, protocol='https', enablehttp2=True, licenseServer=licenseServer):
        return MW(self.logger, self, host, port, protocol, enablehttp2, licenseServer)

    def newAgent(self, host, port, protocol='https', enablehttp2=True):
        return LizardAgent(self.logger, self, host, port, protocol, enablehttp2)

class Requests(object):
    def get_requests(self):
        if self.httpv2:
            s = requests.Session()
            s.mount(self.baseurl, HTTP20Adapter())
            s.verify = False
            return s
        else:
            return requests

    def get(self, url, params = None, headers = None, stream=False):
        return self.get_requests().get('%s%s' % (self.baseurl, url), params = params, headers = headers, verify = False, stream=stream, timeout=100)

    def getInfoFromURL(self, url, params = None, headers = None):
        return self.get_requests().get('%s' % url, params = params, headers = headers, verify = False)

    def put(self, url, data, headers = None):
        return self.get_requests().put('%s%s' % (self.baseurl, url), data = (None if data is None else json.dumps(data)), headers = headers, verify = False, timeout=100)

    def putText(self, url, data, headers = None):
        return self.get_requests().put('%s%s' % (self.baseurl, url), data = data, headers = headers, verify = False)

    def post(self, url, data=None, headers = None):
        return self.get_requests().post('%s%s' % (self.baseurl, url), data = (None if data is None else json.dumps(data)), headers = headers, verify = False, timeout=100)

    def patch(self, url, data, headers = None):
        return self.get_requests().patch('%s%s' % (self.baseurl, url), data = (None if data is None else json.dumps(data)), headers = headers, verify = False, timeout=100)

    def delete(self, url, headers = None):
        return self.get_requests().delete('%s%s' % (self.baseurl, url), headers = headers, verify = False)

    def head(self, url, headers = None):
        return self.get_requests().head('%s%s' % (self.baseurl, url), headers = headers, verify = False)

    def options(self, url, headers = None):
        return self.get_requests().options('%s%s' % (self.baseurl, url), headers = headers, verify = False)

    def post_zip(self, url, data=None, headers=None):
        headers["Content-Type"] = "application/zip"
        return self.get_requests().post('%s%s' % (self.baseurl, url), data=(None if data is None else data),
                                        headers=headers, verify=False)

class Utils(Requests):

    def waitForState(self, what, equalToWhat, timeout):
        while timeout>0:
            try:
                self.assertEqual(what, equalToWhat)
                return True
            except:
                timeout -= 0.2
                time.sleep(0.2)
        else:
            self.logger.info("Timed out after %s seconds" % (10 - timeout))
            return False
    
    @staticmethod
    def GetIPs():
        ipList = []
        global specs

        filename = 'LoadCoreSetupInfo'

        try:
            with open("../"+filename) as f:     # when running from other folder than root
                temp = f.readlines()
        except:
            with open(filename) as f:       # when running from root
                temp = f.readlines()

        content = [item.strip("\n").replace(" ","") for item in temp ]

        for item in content:
            if item.split("=")[0].startswith('mwIP') or (item.split("=")[0].startswith('agent') and item.split("=")[0] != 'agents'):
                ipList.append(item.split("=")[1])
            if item.split("=")[0].startswith('specs'):
                specs = item.split("=")[1]
        # print(ipList)
        return ipList
    
staticToken = None
#licenseServer = "10.38.158.250"

class MW(Utils):
    def __init__(self, logger, testcase=None, host='localhost', port=48484, protocol='https', enablehttp2=True, licenseServer=licenseServer):
        self.testcase = testcase
        self.logger = logger
        self.host = host
        self.port = port
        self.protocol = protocol
        self.process = None
        self.coverage = os.environ.get('COVERAGE') == '1'
        self.builddir = self.coverage and '.build/native-lcov' or '.build/native'
        self.iplist = []
        self.baseurl = '%s://%s:%d' % (self.protocol, self.host, self.port)
        self.httpv2 = enablehttp2
        self.cookie = self.getAutomationToken()
        self.headers = {'authorization': self.cookie}
        self.setLicenseServer(licenseServer)
    
    def refreshToken(func):
        def wrapper(self, *args, **kwargs):
            response = func(self, *args, **kwargs)
            if response.status_code == 401:     # refresh token
                self.logger.debug('Refreshing the token..')
                self.headers = {'authorization': self.getAutomationToken()}
                response = func(self, *args, **kwargs)
            return response
        return wrapper

    @refreshToken
    def get(self, url, params = None, headers = None):
        return super().get(url, params = params, headers = self.headers)

    @refreshToken
    def put(self, url, data, headers = None):
        return super().put(url, data = data, headers = self.headers)

    @refreshToken
    def post(self, url, data=None, headers = None):
        return super().post(url, data = data, headers = self.headers)

    @refreshToken
    def delete(self, url, headers = None):
        return super().delete(url, headers = self.headers)

    @refreshToken
    def patch(self, url, data=None, headers= None):
        return super().patch(url, data = data, headers = self.headers)

    @refreshToken
    def post_zip(self, url, data=None, headers = None):
        return super().post_zip(url, data = data, headers = self.headers)

    def newSession(self, configName=None, configID=None, configJson=None, configArchive=None, statusCode=201, sessionType='dusimsa'):
        """
        :param configName:
        :param configID: specify a configID to create a new config and load the config with configID
        :param config: config in json format that will be uploaded and attached to the new session
        :return: new session ID
        """

        if sessionType == "dusimsa":
            configType = "wireless-du-sim-sa-config"
            #configType = "wireless-empty-config"
        elif sessionType == "SBA":
            configType = "wireless-sba-config"
        elif sessionType == "UPF Isolation":
            configType = "wireless-upf-isolation-config"
        elif sessionType == "cusim":
            configType = "wireless-cusim-config"

        if (configName == None and configJson == None and configID == None and configArchive == None):
            config = {"ConfigUrl": configType}
        elif configID != None:
            config = {"ConfigUrl": configID}
        elif (configName != None):
            # in this case create a new config by loading a specified config name
            config = self.selectConfig(configName)
            uploadedConfig = self.uploadConfig(config=config)
            config = {"ConfigUrl": 'configs/' + uploadedConfig[0]['id']}
        elif (configJson != None):
            uploadedConfig = self.uploadConfig(config=configJson)
            config = {"ConfigUrl": 'configs/' + uploadedConfig[0]['id']}
        elif configArchive != None:
            uploadedConfig = self.uploadConfig(configArchive=configArchive)
            config = {"ConfigUrl": 'configs/' + uploadedConfig[0]['id']}
        else:
            self.logger.error("NewSession: Unhandled case")
        response = self.post('/api/v2/sessions', config, headers=self.headers)
        #print(response)
        #print(response.content)
        self.testcase.assertEquals(response.status_code, statusCode)
        if statusCode == 201:
            self.logger.debug(pformat(response.json()))
            self.logger.info("Started new mw session with Index: %s and ID: %s" % (response.json()[0]['index'], response.json()[0]['id']))
            return response.json()[0]['id']# Aici mi se pare ca nu ar trebui sa fie o lista
        else:
            # print response
            # print response.content
            return response.json()

    def deleteSession(self, sessionID, statusCode=204):
        response = self.delete('/api/v2/sessions/{0}'.format(sessionID), headers=self.headers)
        #self.logger.debug(pformat(response.json()))
        # self.testcase.assertEquals(response.status_code, statusCode)
        if '200' in str(response.status_code):
            self.testcase.assertTrue(True if sessionID not in self.getAllSessions() else False)
            return response
        elif '204' in str(response.status_code):
            self.testcase.assertTrue(True if sessionID not in self.getAllSessions() else False)
            return response
        elif '400' in str(response.status_code):
            return response
        else:
            self.logger.debug(pformat(response))
            return response.status_code

    def getAllSessions(self):
        response = self.get('/api/v2/sessions', headers=self.headers)
        self.testcase.assertEquals(response.status_code, 200)
        sessions = []
        for item in response.json():
            sessions.append(item['id'])

        return sessions


    def getAllConfigs(self):
        response = self.get('/api/v2/configs', headers=self.headers)
        self.testcase.assertEquals(response.status_code, 200)
        sessions = []
        for item in response.json():
            sessions.append(item['id'])

        return sessions

    def getSessionInfo(self, sessionID, statusCode=200):
        response = self.get('/api/v2/sessions/{0}'.format(sessionID), headers=self.headers)
        self.testcase.assertEquals(response.status_code, statusCode)
        return response.json()

    def getSessionStatus(self, sessionID):
        response = self.get('/api/v2/sessions/{0}/test'.format(sessionID), headers=self.headers)
        self.testcase.assertEquals(response.status_code, 200)
        return response.json()['status']

    def isSessionStarted(self, sessionID):
        response = self.get('/api/v2/sessions/{0}/test'.format(sessionID), headers=self.headers)
        self.testcase.assertEquals(response.status_code, 200)
        return True if response.json()['status'] == 'Started' else False
    
    def isSessionOpen(self, sessionID, licenseServer, returnLicenses=False, waitTime=100):
        elapsedTime = 10
        testResponse = self.get('/api/v2/sessions/{0}/test'.format(sessionID), headers=self.headers)  
        if returnLicenses and (testResponse.json()['status'] == 'STARTED'):
            s = requests.Session()
            s.post("https://%s:7443/rest/license/login" % licenseServer, data={"userid":"admin", "password":"admin"}, verify=False)
            licensesAfterStartTest = s.get('https://%s:7443/rest/license/floatingStats' % licenseServer, verify=False).json()
            s.close()

        while elapsedTime < waitTime and testResponse.json()['status'] != 'STOPPED':
            try:
                testResponse = self.get('/api/v2/sessions/{0}/test'.format(sessionID), headers=self.headers)
            except ConnectionError as e:
                break
            time.sleep(5)
            elapsedTime += 5
        return (True if self.get('/api/v2/sessions/{0}/test'.format(sessionID), headers=self.headers).json()['status'] != 'Stopped' else False), licensesAfterStartTest if returnLicenses else None
    
    def getTestDuration(self, sessionID, extraTime=30):
        response = self.get('/api/v2/sessions/{0}/test'.format(sessionID), headers=self.headers)
        self.testcase.assertEquals(response.status_code, 200)
        total_duration = response.json()['testDuration'] + extraTime
        return total_duration

    def checkSessionState(self, sessionID, status, waitTime=300):
        elapsedTime = 0
        testResponse = self.get('/api/v2/sessions/{0}/test'.format(sessionID), headers=self.headers)  
        while elapsedTime < waitTime and testResponse.json()['status'] != status:
            try:
                testResponse = self.get('/api/v2/sessions/{0}/test'.format(sessionID), headers=self.headers)
                self.logger.debug(pformat(testResponse.json()))
            except ConnectionError as e:
                break
            time.sleep(5)
            elapsedTime += 5
        return True if testResponse.json()['status'] == status else False

    def pickExistingSession(self, wildcard):
        try:
            self.assertGreater(self.newSessionID, 0)
            return self.newSessionID
        except:
            allSessions = self.getAllSessions()
            for session in allSessions:
                if wildcard in session:
                    return session

    def getAllAgents(self):
        """
        :return: a list of agents
        """
        response = self.get('/api/v2/agents', headers=self.headers)
        self.testcase.assertEquals(response.status_code, 200)
        return response.json()

    def getAgentInfo(self, agentID):
        response = self.get('/api/v2/agents/{0}'.format(agentID), headers=self.headers)
        self.testcase.assertEquals(response.status_code, 200)
        
        return response.json()

    def getAgentIP(self, agentID):
        response = self.getAgentInfo(agentID)

        return response['IP']

    def getSessionConfig(self, sessionID, statusCode=200):
        response = self.get('/api/v2/sessions/{0}/config?include=all'.format(sessionID), headers=self.headers)
        #self.logger.debug(pformat(response.json()))
        self.testcase.assertEquals(response.status_code, statusCode)
        return response.json()

    def selectConfig(self, configName):
        self.logger.debug("Selecting config:%s" % configName)
        configFileName = '{0}.json'.format(configName)
        assert os.path.isfile(configFileName)

        file = open(configFileName)
        config = file.read()
        file.close()

        configJson = json.loads(config)
        # self.logger.debug(pformat(configJson))
        return configJson

    def updateConfigAgents(self, configToModify, agentsDict, sbaTesterTopology=False):
        """
        :param agentsDict: { node : agentID , node2: agentID, , node3: agentID2}
            e.g. { 'amf' : ['d7ee6d0b-9b3b-4cf2-8cfa-8481d02b1a7f'] , 'ng-ran: ['d7ee6d0b-9b3b-4cf2-8cfa-8481d02b1a7f']}
        :return: updated config
        """
        import copy
        newConfig = copy.deepcopy(configToModify)
        for node in agentsDict:
            newConfig['configData']['Config' if sbaTesterTopology is False else 'SBAConfig']['nodes'][node]['settings']['mappedAgents'][0]['agentId'] = agentsDict[node][0]
            # newConfig['nodes'][node]['settings']['agents'] = agentsDict[node]

        return newConfig

    def setSessionConfig(self, sessionID, config, statusCode=200, sbaTesterTopology=False):
        self.headers.update({'Content-Type': 'application/json',
                   'Accept': '*/*',
                   'Cache-Control': 'no-cache',
                   'Host': '{0}'.format(self.host),
                   'Accept-Encoding': 'gzip, deflate',
                   'Referer': 'http://{0}/api/v2/sessions'.format(self.host),
                   'Postman-Token': '009256e4-5703-4564-8526-adfe3567fecd',
                   'User-Agent': 'PostmanRuntime/7.16.3',
                   'Connection': 'keep-alive'})

        # this is a workaround for the fact that converting dict to json will change SBAConfig from null to None and
        # this will make the config to throw and error when it is loaded
        if config['configData']['SBAConfig'] == None:
            del config['configData']['SBAConfig']

        if 'configData' in config:
            config = config['configData']['Config' if sbaTesterTopology is False else 'SBAConfig']

        #response = self.put('/api/v2/sessions/{0}/config/config'.format(sessionID), data=config, headers=self.headers)
        response = self.put('/api/v2/sessions/{0}/config/config'.format(sessionID) if sbaTesterTopology is False
                            else '/api/v2/sessions/{0}/config/sbaConfig'.format(sessionID), data=config, headers=self.headers)
        self.logger.debug(pformat(response.content))
        self.logger.debug(pformat(response.reason))
        self.testcase.assertEquals(response.status_code, statusCode)
        try:
            return response.json()
        except:
            return response

    def getTestDetails(self, sessionID, statusCode=200):
        response = self.get('/api/v2/sessions/{}/test'.format(sessionID), headers=self.headers)
        self.testcase.assertEquals(response.status_code, statusCode)

        return response.json()['testDetails']

    def startTest(self, sessionID, result='SUCCESS', wait=40, statusCode=202):
        response = self.post('/api/v2/sessions/{0}/test-run/operations/start'.format(sessionID), headers=self.headers)
        self.logger.debug(pformat(response.content))
        self.logger.debug(pformat(response.json()))

        self.testcase.assertEquals(response.status_code, statusCode)
        waitTime = wait

        # state = self.get('/api/v2/sessions/{0}/test-run/operations/start/{1}'.format(sessionID, response.json()['id']), headers=self.headers)

        # # workaround to work on both branches until merge
        # if state.status_code == 200:
        #     good_url = '/api/v2/sessions/{0}/test-run/operations/start/{1}'.format(sessionID, response.json()['id'])
        # else:
        #     good_url = '/api/v2/sessions/{0}/operations/start/{1}'.format(sessionID, response.json()['id'])
        good_url = '/api/v2/sessions/{0}/test-run/operations/start/{1}'.format(sessionID, response.json()['id'])

        while wait > 0:      
            try:
                state = self.get(good_url, headers=self.headers)
                self.logger.debug(pformat(state))
                self.logger.debug(pformat(state.content))

                if state.json()['state'] == result:
                    self.logger.debug("Waiting {} seconds".format(wait))
                    self.logger.debug("Waited {} seconds".format(200-int(wait)))
                    return state.json()

                if state.json()['state'] == 'ERROR':  # break when start goes to ERROR state
                    break

                wait -= 1
                time.sleep(1)
                self.logger.debug(pformat(state.json()))

            except:
                return response.json()

        else:
            return state.json()['state']

        # if state is ERROR, stop the test and print the error message.
        msg = self.get('/api/v2/sessions/{}/test'.format(sessionID), headers=self.headers)
        print("msg:" + msg.json()['testDetails'])
        #self.testcase.assertTrue(False, msg='State: {} - MSG: {}'.format(state.json()['state'], msg.json()['testDetails']))  

    def stopTest(self, sessionID, result='SUCCESS', wait=40, statusCode=202):
        response = self.post('/api/v2/sessions/{0}/test-run/operations/stop'.format(sessionID), headers=self.headers)
        self.logger.debug(pformat(response.content))
        self.logger.debug(pformat(response.status_code))

        self.testcase.assertEquals(response.status_code, statusCode)
        waitTime = wait

        # state = self.get('/api/v2/sessions/{0}/test-run/operations/stop/{1}'.format(sessionID, response.json()['id']), headers=self.headers)

        # workaround to work on both branches until merge
        # if state.status_code == 200:
        #     good_url = '/api/v2/sessions/{0}/test-run/operations/stop/{1}'.format(sessionID, response.json()['id'])
        # else:
        #     good_url = '/api/v2/sessions/{0}/operations/stop/{1}'.format(sessionID, response.json()['id'])
        good_url = '/api/v2/sessions/{0}/test-run/operations/stop/{1}'.format(sessionID, response.json()['id'])

        while wait > 0:
            try:
                state = self.get(good_url, headers=self.headers)
                self.logger.debug(pformat(state))
                self.logger.debug(pformat(state.content))

                if state.json()['state'] == result:
                    return state.json()

                if state.json()['state'] == 'ERROR':  # break when start goes to ERROR state
                    break

                wait -= 1
                time.sleep(1)
                self.logger.debug(pformat(state.json()))

            except:
                return response.json()

        else:
            self.testcase.assertTrue(False, msg='Test failed to stop in {} seconds'.format(waitTime))

        # if state is ERROR, stop the test and print the error message.
        msg = self.get('/api/v2/sessions/{}/test'.format(sessionID), headers=self.headers)
        #self.testcase.assertTrue(False, msg='State: {} - MSG: {}'.format(state.json()['state'], msg.json()['testDetails']))  

    def abortTest(self, sessionID, result='SUCCESS', wait=40, statusCode=202):
        response = self.post('/api/v2/sessions/{0}/test-run/operations/abort'.format(sessionID), headers=self.headers)
        self.logger.debug(pformat(response.content))
        self.logger.debug(pformat(response.status_code))

        self.testcase.assertEquals(response.status_code, statusCode)
        waitTime = wait

        good_url = '/api/v2/sessions/{0}/test-run/operations/abort/{1}'.format(sessionID, response.json()['id'])

        while wait > 0:
            try:
                state = self.get(good_url, headers=self.headers)
                self.logger.debug(pformat(state))
                self.logger.debug(pformat(state.content))

                if state.json()['state'] == result:
                    return state.json()

                if state.json()['state'] == 'ERROR':  # break when start goes to ERROR state
                    break

                wait -= 1
                time.sleep(1)
                self.logger.debug(pformat(state.json()))

            except:
                return response.json()

        else:
            self.testcase.assertTrue(False, msg='Test failed to stop in {} seconds'.format(waitTime))

        # if state is ERROR, stop the test and print the error message.
        msg = self.get('/api/v2/sessions/{}/test'.format(sessionID), headers=self.headers)
        self.testcase.assertTrue(False, msg='State: {} - MSG: {}'.format(state.json()['state'], msg.json()['testDetails']))  

    def getNodeAgent(self, sessionID, node):
        import pprint
        # pprint.pprint(self.getSessionConfig(sessionID, statusCode=200))
        self.logger.debug(pformat(self.getSessionConfig(sessionID, statusCode=200)))

        try:
            return self.getSessionConfig(sessionID, statusCode=200)['Config']['nodes'][node]['settings']['mappedAgents'][0]['agentId']
        except:
            #This is a workaround for the fact that at some point the 'udm' appears in the config as 'Udm'
            return self.getSessionConfig(sessionID, statusCode=200)['Config']['nodes'][node.capitalize()]['settings']['mappedAgents'][0]['agentId']

    def uploadConfig(self, config=None, configArchive=None, statusCode=201):
        """
        :param config: in json format
        :return:
        """
        if config != None:
            response = self.post('/api/v2/configs', data=config, headers=self.headers)
            # self.logger.debug(pformat(response.content))
            self.logger.debug(pformat(response.reason))
            self.testcase.assertEquals(response.status_code, statusCode)
            return response.json()
        if configArchive != None:
            with open(configArchive, 'rb') as f:
                response = self.post_zip('/api/v2/configs',data=f, headers=self.headers)
                # self.logger.debug(pformat(response.content))
                self.logger.debug(pformat(response.reason))
                self.testcase.assertEquals(response.status_code, statusCode)
                return response.json()

    def deleteUploadedConfig(self, idConfig, statusCode=204):
        """
        delete uploaded config
        """
        response = self.delete('/api/v2/configs/%s' % idConfig, headers=self.headers)
        self.testcase.assertEquals(response.status_code, statusCode)

    def getUploadedConfig(self, configID, params='', statusCode=200):
        response = self.get('/api/v2/configs/{0}{1}'.format(configID, params), headers=self.headers)
        self.testcase.assertEquals(response.status_code, statusCode)
        return response.json()

    def getWithHeaders(self, url, statusCode=200):
        response = self.get('{0}'.format(url), headers=self.headers)
        self.testcase.assertEquals(response.status_code, statusCode)
        return response.json()

    def getAgent(self, node, config):

        try:
            return config['nodes'][node]['settings']['agents']
        except:
            #This is a workaround for the fact that at some point the 'udm' appears in the config as 'Udm'
            return config['nodes'][node.capitalize()]['settings']['agents']

    def getAutomationToken(self):
        self.logger.debug('Getting the cookie...')
        global staticToken
        UIusername = 'admin'
        UIpassword = 'admin'

        try:
            # TODO: workaround to work on both releases.
            if staticToken:
                return staticToken

            # generate an access_token
            apiPath = '/auth/oauth2/token?grant_type=client_credentials'
            payload = '{}'
            wapAutomationAuth = 'Y2x0LXdhcC1hdXRvbWF0aW9uOmR1bW15LXdhcC1hdXRvbWF0aW9uLXNlY3JldA=='
            self.headers = {'Content-Type': 'application/x-www-form-urlencoded',
                    'authorization': 'Basic {}'.format(wapAutomationAuth)}

            response = self.post(apiPath, payload, headers=self.headers)
            # TODO: workaround to work on both releases
            if response.status_code == 200:
                # print('Access Token: {}'.format(response.json()["access_token"]))
                staticToken = response.json()["access_token"]
            else:
                apiPath = '/auth/realms/keysight/protocol/openid-connect/token'
                self.headers = {'Content-Type': 'application/x-www-form-urlencoded'}
                payload = { "grant_type" : "password", "username" : UIusername, "password": UIpassword, "client_id": "clt-wap" }
                # use requests.post because payload is not json format as it is used in self.post()
                response = requests.post(self.baseurl + apiPath, data=payload, headers=self.headers, verify=False)
                # print('Access Token: {}'.format(response.json()['access_token']))
                staticToken = response.json()["access_token"]
        except Exception as e:
            self.logger.info("Error is %s: ", e)
            return ""

        return response.json()["access_token"]

    def setLicenseServer(self, licenseServer, licenseType='ExternalKCOS'):
        response = self.get('/api/v2/globalsettings', headers=self.headers)
        wait = 220
        if response.status_code != 200:     # if cluster is working, skip the next part
            while wait > 0:
                print("Current Status - HTTP Response Code is: %s" % response.status_code)
                if response.status_code != 200:     # if cluster is not working, keep trying
                    response = self.get('/api/v2/globalsettings', headers=self.headers)
                    wait-= 20
                    time.sleep(20)
                else:                               # if cluster is back online, let me know
                    print("WDM is up again - Check if previous test crashed it")
                    break
            else:
                self.testcase.assertTrue(False, "The cluster is not running properly after %s seconds" % wait)

        self.testcase.assertEqual(response.status_code, 200, response.json())

        # global licenseServer

        if response.json()["licenseServer"] == licenseServer:
            #print "already there"
            return 0
        #print "license server not configured"
        payload = {"licenseServer": licenseServer, "licenseType": licenseType}
        response = self.put('/api/v2/globalsettings', payload, headers=self.headers)
        # wordaround for both branches
        if response.status_code == 405:
            response = self.put('/api/v2/globalsettings', payload, headers=self.headers)
        # print(response.content)


    def getNodeAgentFromIP(self, ipaddr):
        response = self.get('/api/v2/agents', headers=self.headers)
        self.testcase.assertEquals(response.status_code, 200)
        agents=response.json()
        if agents[0]['IP'] == ipaddr:
            return agents[0]['id']
        else:
            return agents[1]['id']

    def getTestId(self, sessionID, statusCode=200):
        response = self.get('/api/v2/sessions/{0}/test'.format(sessionID), headers=self.headers)
        self.testcase.assertEquals(response.status_code, statusCode)
        return response.json()['testId']


    def getAllStats(self, testId, statName, statusCode=200):
        response = self.get('/api/v2/results/{0}/stats/{1}'.format(testId, statName), headers=self.headers)
        self.testcase.assertEquals(response.status_code, statusCode)
        col = {}
        statList = []

        try:
            for i in range(len(response.json()['columns']) - 1):
                n = response.json()['columns'][i+1]
                for j in range(len(response.json()['snapshots'])):
                    statList.append(float(response.json()['snapshots'][j]['values'][0][i+1]))
                col[n] = statList
                statList = []

            return col
        except:
            self.logger.info("Exception raised: No stats available for {}. Test didn't run as expected".format(statName))
            raise

    def getHttpStats(self, testId, statName, statusCode=200):
        response = self.get('/api/v2/results/{0}/stats/{1}'.format(testId, statName), headers=self.headers)
        self.testcase.assertEquals(response.status_code, statusCode)
        col = {}
        statList = []

        for j in range(len(response.json()['snapshots'][0]['values'])):
            for i in range(len(response.json()['columns'])-1):
                n = response.json()['snapshots'][0]['values'][j][0].split('@')[1]
                statList.append(float(response.json()['snapshots'][0]['values'][j][i+1]))
            col[n] = statList
            statList = []
        return col

    def getAvgNonZeroStat(self, stat):
        statList = []
        for i in stat:
            if i != 0:
                statList.append(i)
        if len(statList) == 0:
            return 0
        else:
            return round(sum(statList) / len(statList), 2)

    def getAgentsInfo(self):
        response = self.get('/api/v2/agents', headers=self.headers)
        self.testcase.assertEquals(response.status_code, 200)
        # self.logger.debug(pformat(response.json()))
        agents=response.json()
        agents_list = []
        for agent in agents:
            interface_list = []
            for interface in agent['Interfaces']:
                interface_list.append({'Name': interface['Name'], 'Mac': interface['Mac']})
            interface_list.sort(key=lambda x: x['Name'])
            agents_list.append({'id':agent['id'], 'IP':agent['IP'], 'Interfaces': interface_list})
        return agents_list

    #This function is used in my testing because getAgentsInfo is providing me 401 Unauthorized when retrieving agents list from agent-controller 
    def getAgentsInfo2(self):
        response = self.get('/api/v2/agents', headers=self.headers)
        self.testcase.assertEquals(response.status_code, 200)
        # self.logger.debug(pformat(response.json()))
        agents=response.json()
        agents_list = []
        for agent in agents:
            interface_list = []
            for interface in agent['Interfaces']:
                interface_list.append({'Name': interface['Name'], 'Mac': interface['Mac']})
            interface_list.sort(key=lambda x: x['Name'])
            agents_list.append({'id':agent['id'], 'IP':agent['IP'], 'Interfaces': interface_list})
        return agents_list

    def getAgentDetails(self, agentsInfo, agentIP):
        for agent in agentsInfo:
            if agent['IP'] == agentIP:
                #print("Returned info for agent with IP %s: | Details: \n %s" % (agentIP, agent))   # uncomment for extra debug
                return agent

    def getAgentNodeID(self, agentsInfo, agentIP):
        for agent in agentsInfo:
            if agent['IP'] == agentIP:
                return agent['id']

    def getAgentInterfaces(self, agentsInfo, agentIP):
        for agent in agentsInfo:
            if agent['IP'] == agentIP:
                return agent['Interfaces']
    
    def getInterfaceMAC(self, agentsInfo, agentIP, interfaceName):
        for agent in agentsInfo:
            if agent['IP'] == agentIP:
                for interface in agent['Interfaces']:
                    if interface['Name'] == interfaceName:
                        return interface['Mac']    

    def updateConfig(self, configToModify, remapDict, topology):
        import copy
        newConfig = copy.deepcopy(configToModify)

        for node in remapDict:
            try:
                isNodeEnabled = True if newConfig['configData'][topology]['nodes'][node]['settings']['enable'] == True else False
                isNodeDN = False
            except KeyError as e:
                isNodeEnabled = False
                if node == "dn":            # case sensitive
                    isNodeDN = True
                else:
                    isNodeDN = False

            if isNodeEnabled or isNodeDN:
                config_path = newConfig['configData'][topology]['nodes'][node]['settings']['mappedAgents']
                for k in range(len(config_path)):
                    for key in remapDict[node][k]:
                        if key == 'id':
                            config_path[k]['agentId'] = remapDict[node][k][key]
                        elif key != 'interfaces':
                            for i in range(len(config_path[k]['interfaceMappings'])):
                                if key == config_path[k]['interfaceMappings'][i]['nodeInterface']:
                                    # print(key, agentsDict[node][key][0], agentsDict[node][key][1])
                                    config_path[k]['interfaceMappings'][i]['agentInterface'] = remapDict[node][k][key]['Name']
                                    config_path[k]['interfaceMappings'][i]['agentInterfaceMac'] = remapDict[node][k][key]['Mac']
                        else:
                            for i in range(len(config_path[k]['interfaceMappings'])):
                                if node in ['upf','ran'] and config_path[k]['interfaceMappings'][i]['nodeInterface'] in ['n6','passthroughDevice']:
                                    config_path[k]['interfaceMappings'][i]['agentInterface'] = 'none'
                                    config_path[k]['interfaceMappings'][i]['agentInterfaceMac'] = 'none'
                                elif node in ['smf'] and topology == 'upf-isolation' and config_path[k]['interfaceMappings'][i]['nodeInterface'] in ['passthroughDevice']:
                                    config_path[k]['interfaceMappings'][i]['agentInterface'] = 'none'
                                    config_path[k]['interfaceMappings'][i]['agentInterfaceMac'] = 'none'
                                else:
                                    config_path[k]['interfaceMappings'][i]['agentInterface'] = remapDict[node][k]['interfaces'][0]['Name']
                                    config_path[k]['interfaceMappings'][i]['agentInterfaceMac'] = remapDict[node][k]['interfaces'][0]['Mac']

        return newConfig

    def getTopologyFromSessionConfig(self, config):
        category = config['ConfigType']

        if category == 'Full Core':
            return 'Config'
        elif category == 'SBA':
            return 'sbaConfig'
        elif category == 'UPF Isolation':
            return 'upfIsolationConfig'
        elif category == 'CUSIM':
            return 'cusimConfig'
        elif category == 'DuSimSa':
            #return 'IRATConfig'
            return 'DuSimSaConfig'
        elif category == 'Core Sim':
            return 'coreSimConfig'
        elif category == 'IP Endpoints':
            return 'ipEndpointsConfig'

    def getTopologyFromConfig(self, config):
        category = config['tags']['category']

        if category == 'Full Core':
            return 'Config'
        elif category == 'SBA':
            return 'SBAConfig'
        elif category == 'UPF Isolation':
            return 'UpfIsolationConfig'
        elif category == 'iRAT':
            return 'IRATConfig'

    def updateNetworkSettings(self, configToModify, networkSettings, topology, fromSession=0):
        import copy
        newConfig = copy.deepcopy(configToModify)
        AgentsInfo = self.getAgentsInfo()

        # modify networkSettings structure
        agentsInfos = []

        for agent in networkSettings:
            d = {'agentId':agent, \
                'id': '', \
                'impairmentId': '-1'
                }
            temp = []
            for interface in networkSettings[agent]:
                temp.append({'capture': False, 'interfaceName': interface, 'interfaceMac': self.getInterfaceMAC(AgentsInfo, self.getAgentIP(agent), interface), \
                            "networkStack": "linuxStack", "sriov": False})
            d['interfacesSettings'] = temp
            agentsInfos.append(d)

        # a config json file is different from a config extracted from session
        if fromSession == 0:
            newConfig['configData'][topology]['networkSettings']['agentsInfos'] = agentsInfos
        else:
            newConfig[topology]['networkSettings']['agentsInfos'] = agentsInfos
        # print(newConfig['configData'][path])

        return newConfig

    def patchImpairmentProfile(self, sessionID, agentIP, impairmentId):
        config = self.getSessionConfig(sessionID)
        topology = self.getTopologyFromSessionConfig(config)
        AgentsInfo = self.getAgentsInfo()
        networkSettings = config[topology]['networkSettings']
        agentId = self.getAgentNodeID(AgentsInfo, agentIP)

        for agent in networkSettings['agentsInfos']:
            if agent['agentId'] == agentId:
                agent["impairmentId"] = impairmentId

        if topology == 'Config':
            topology = topology.lower()
        response = self.patch('/api/v2/sessions/{}/config/{}/networkSettings'.format(sessionID, topology), data=networkSettings)
        self.testcase.assertEqual(response.status_code, 204)

    def patchRebootAgent(self, sessionID, agentIP, rebootAgent=False):
        config = self.getSessionConfig(sessionID)
        topology = self.getTopologyFromSessionConfig(config)
        AgentsInfo = self.getAgentsInfo()
        networkSettings = config[topology]['networkSettings']
        agentId = self.getAgentNodeID(AgentsInfo, agentIP)

        for agent in networkSettings['agentsInfos']:
            if agent['agentId'] == agentId:
                agent["rebootAgent"] = rebootAgent
        
        if topology == 'Config':
            topology = topology.lower()
        response = self.patch('/api/v2/sessions/{}/config/{}/networkSettings'.format(sessionID, topology), data=networkSettings)
        self.testcase.assertEqual(response.status_code, 204)

    def patchNetworkSettings(self, sessionID, agentIP, interface, **kwargs):
        """
        Used to manipulate capture, networkStack and sriov. This options are available per interface
        
        'networkStack': 'linuxStack' -> for linuxstack

        'networkStack': 'ixStack' -> ixStack with Raw Sockets

        'networkStack': 'dpdk' -> ixStack with DPDK

        'capture': True / False

        'sriov': True / False

        """      
        config = self.getSessionConfig(sessionID)
        topology = self.getTopologyFromSessionConfig(config)
        AgentsInfo = self.getAgentsInfo()
        networkSettings = config[topology]['networkSettings']
        agentId = self.getAgentNodeID(AgentsInfo, agentIP)
        
        for agent in networkSettings['agentsInfos']:
            if agent['agentId'] == agentId:
                for interfaceName in agent['interfacesSettings']:
                    if interfaceName['interfaceName'] == interface:
                        interfaceName['interfaceMac'] = self.getInterfaceMAC(AgentsInfo, agentIP, interface)
                        for key, value in kwargs.items():
                            interfaceName[key] = value
        # workaround for fullcore. the api url is lower case
        if topology == 'Config':
            topology = topology.lower()
        response = self.patch('/api/v2/sessions/{}/config/{}/networkSettings'.format(sessionID, topology), data=networkSettings)
        self.testcase.assertEqual(response.status_code, 204)

    def newRemap(self, configToModify, agentsDict, topology="full-core"):
        """
        four remap methods:
        1. agentsDict[node] = self.lizardAgent1 
            it will use the agent's first test interface

        2. agentsDict[node] = [{'agent': self.lizardAgent2, 'n3': 'ens160', 'n4': 'ens160', 'n6': 'none' , 'n9': 'ens160'}]
            it will remap the node as described in the dict

        3. agentsDict[node] = [(self.lizardAgent1, 'ens192')]
            it will use the exact test interface (ens192)
        
        4. agentsDict[node] = [self.lizardAgent1, self.lizardAgent2]
            this is used to remap multiple agents on every node

        """
        agentsInfo = self.getAgentsInfo()
        remapDict = {}
        d = {}      # used for networkSettings information

        # upload config to be upgraded
        uploadedID = self.uploadConfig(configToModify)[0]['id']
        configToModify = self.getUploadedConfig(uploadedID, params='?include=all')
        self.deleteUploadedConfig(uploadedID)   # delete dummy config
        topology = self.getTopologyFromConfig(configToModify)

        for node in agentsDict:
            if type(agentsDict[node]) is not list:                  # agentsDict[node] = self.lizardAgent1
                # print("Detected string - converting to list...")
                agentsDict[node] = agentsDict[node].split("-")
            remapDict[node] = []
            for agent in agentsDict[node]:        # multiple agents support
                if type(agent) is dict:    #  agentsDict[node] = [{'agent': self.lizardAgent2, 'n3': 'ens160', 'n4': 'ens160', 'n6': 'none' , 'n9': 'ens160'}]
                    remapTempDict = {}
                    try:
                        remapTempDict['id'] = self.getAgentNodeID(agentsInfo, agent['agent'])
                    except:
                        self.logger.error("Something is wrong in LoadCoreSetupInfo file: check for agents IPs (they must be connected to the MW), interface names on each test...")
                        raise
                    if agent['agent'] not in d:     
                        d[agent['agent']] = []      # if agent is not in dict, add it
                    for key in agent:
                        if agent[key] == 'none':
                            remapTempDict[key] = {'Name': agent[key], \
                            'Mac': 'none'}
                        elif key != 'agent':
                            remapTempDict[key] = {'Name': agent[key], \
                            'Mac': self.getInterfaceMAC(agentsInfo, agent['agent'], agent[key])}
                            if agent[key] not in d[agent['agent']]:
                                d[agent['agent']].append(agent[key])    # if interface not in dict[agent], add it           
                    remapDict[node].append(remapTempDict)
                
                elif type(agent) is tuple:      # agentsDict[node] = [(self.lizardAgent2, 'ens160')]
                    if agent[0] in d:
                        if agent[1] not in d[agent[0]]:
                            d[agent[0]].append(agent[1])    # if interface not in dict[agent], add it
                    else:
                        d[agent[0]] = []    # if agent is not in dict, add it
                        d[agent[0]].append(agent[1])
                    remapTempDict = {}
                    try:
                        remapTempDict['id'] = self.getAgentNodeID(agentsInfo, agent[0])
                    except:
                        self.logger.error("Something is wrong in LoadCoreSetupInfo file: check for agents IPs (they must be connected to the MW), interface names on each test...")
                        raise
                    remapTempDict['interfaces'] = [{'Name': agent[1], \
                    'Mac': self.getInterfaceMAC(agentsInfo, agent[0], agent[1])}]
                    remapDict[node].append(remapTempDict)

                else:
                    try:
                        inter = self.getAgentInterfaces(agentsInfo, agent)[0]['Name']
                    except:
                        self.logger.error("Something is wrong in LoadCoreSetupInfo file: check for agents IPs (they must be connected to the MW), interface names on each test...")
                        raise
                    if agent in d:
                        if inter not in d[agent]:
                            d[agent].append(inter)  # if interface not in dict[agent], add it
                    else:
                        d[agent] = []        # if agent is not in dict, add it
                        d[agent].append(inter)
                    remapTempDict = {}
                    remapTempDict['id'] = self.getAgentNodeID(agentsInfo, agent)
                    remapTempDict['interfaces'] = [{'Name': self.getAgentInterfaces(agentsInfo, agent)[0]['Name'], \
                    'Mac': self.getAgentInterfaces(agentsInfo, agent)[0]['Mac']}]
                    remapDict[node].append(remapTempDict)


        networkSettings = {}
        for agent in d:
            networkSettings[self.getAgentNodeID(agentsInfo,agent)] = d[agent]   # create a dict with keys as agentNodeID and interfaces list as elements
        configToModify = self.updateNetworkSettings(configToModify, networkSettings, topology=topology)  # modify networkSettings if present

        # temporary code; patch config with the desired spec version
        try:
            if specs != configToModify['configData'][topology]['globalSettings']['techSpecVersion']:
                configToModify['configData'][topology]['globalSettings']['techSpecVersion'] = specs
        except:
            pass

        return self.updateConfig(configToModify, remapDict, topology)


    def upgradeConfig(self, config):
        uploadedID = self.uploadConfig(config)[0]['id']
        upgradedConfig = self.getUploadedConfig(uploadedID, params='?include=all')

        return upgradedConfig
    
    def RemapAgents(self, configToModify, agentsDict, topology="full-core"):
        import copy
        newConfig = copy.deepcopy(configToModify)

        path = "Config"
        if topology == "sba-tester":
            path = "SBAConfig"
        elif topology =="upf-isolation":
            path = "UpfIsolationConfig"
        elif topology == 'irat':
            path = "IRATConfig"

        for node in agentsDict:
            if newConfig['configData'][path]['nodes'][node]['settings']['enable'] == True:
                newConfig['configData'][path]['nodes'][node]['settings']['mappedAgents'][0]['agentId'] = agentsDict[node][0]
                for i in range(len(newConfig['configData'][path]['nodes'][node]['settings']['mappedAgents'][0]['interfaceMappings'])):
                    # TODO workaround for a bug
                    if node in ['upf','ran'] and newConfig['configData'][path]['nodes'][node]['settings']['mappedAgents'][0]['interfaceMappings'][i]['nodeInterface'] in ['n6','passthroughDevice']:
                        newConfig['configData'][path]['nodes'][node]['settings']['mappedAgents'][0]['interfaceMappings'][i]['agentInterface'] = 'none'
                        newConfig['configData'][path]['nodes'][node]['settings']['mappedAgents'][0]['interfaceMappings'][i]['agentInterfaceMac'] = 'none'
                    elif node in ['smf'] and topology == 'upf-isolation' and newConfig['configData'][path]['nodes'][node]['settings']['mappedAgents'][0]['interfaceMappings'][i]['nodeInterface'] in ['passthroughDevice']:
                        newConfig['configData'][path]['nodes'][node]['settings']['mappedAgents'][0]['interfaceMappings'][i]['agentInterface'] = 'none'
                        newConfig['configData'][path]['nodes'][node]['settings']['mappedAgents'][0]['interfaceMappings'][i]['agentInterfaceMac'] = 'none'
                    else:
                        newConfig['configData'][path]['nodes'][node]['settings']['mappedAgents'][0]['interfaceMappings'][i]['agentInterface'] = agentsDict[node][1]
                        newConfig['configData'][path]['nodes'][node]['settings']['mappedAgents'][0]['interfaceMappings'][i]['agentInterfaceMac'] = agentsDict[node][2]
        return newConfig

    def RemapAgents2(self, configToModify, agentsDict, networkSettings, indexMappedAgents=0, applicationInterface=None, topology="full-core", enablePassthru=False,\
                updateNetworkSettings=None, archive=False, **kwargs):
        import copy
        newConfig = copy.deepcopy(configToModify)

        remapDict = {}
        d = {}      # used for networkSettings information

        path = "Config"
        if topology == "sba-tester":
            path = "SBAConfig"
        elif topology == "upf-isolation":
            path = "UpfIsolationConfig"
        elif topology == 'irat':
            path = "IRATConfig"

        if updateNetworkSettings:
            if archive:
                return self.updateNetworkSettings(newConfig, networkSettings, topology=path, fromSession=1)
            else:
                uploadedID = self.uploadConfig(newConfig)[0]['id']
            
            newConfig = self.getUploadedConfig(uploadedID, params='?include=all')

            topology = self.getTopologyFromConfig(newConfig)
            return self.updateNetworkSettings(newConfig, networkSettings, topology=path)
            

        for node in agentsDict:
            try:
                if archive: 
                    if node == "dn" or newConfig[path]['nodes'][node]['settings']['enable'] == True:
                        try:
                            newConfig[path]['nodes'][node]['settings']['mappedAgents'][indexMappedAgents]['agentId'] = agentsDict[node][0]
                        except IndexError as e:
                            self.logger.info("ERROR! Index of out range! This usually hapens when the config has no previously assigned agents and the mappedAgents parameter is empty. Check below to see if this is the case.")
                            raise IndexError
                        for i in range(len(newConfig[path]['nodes'][node]['settings']['mappedAgents'][indexMappedAgents]['interfaceMappings'])):
                            if applicationInterface is None:
                                # TODO workaround for a bug
                                if node in ['upf','ran', 'smf'] and newConfig[path]['nodes'][node]['settings']['mappedAgents'][indexMappedAgents]['interfaceMappings'][i]['nodeInterface'] in ['n6','passthroughDevice']:
                                    newConfig[path]['nodes'][node]['settings']['mappedAgents'][indexMappedAgents]['interfaceMappings'][i]['agentInterface'] = 'none'
                                    newConfig[path]['nodes'][node]['settings']['mappedAgents'][indexMappedAgents]['interfaceMappings'][i]['agentInterfaceMac'] = 'none'
                                else:
                                    newConfig[path]['nodes'][node]['settings']['mappedAgents'][indexMappedAgents]['interfaceMappings'][i]['agentInterface'] = agentsDict[node][1]
                                    newConfig[path]['nodes'][node]['settings']['mappedAgents'][indexMappedAgents]['interfaceMappings'][i]['agentInterfaceMac'] = agentsDict[node][2]
                            else:
                                if newConfig[path]['nodes'][node]['settings']['mappedAgents'][indexMappedAgents]['interfaceMappings'][i]['nodeInterface'] == applicationInterface:
                                    # TODO workaround for a bug
                                    if node == 'upf' and newConfig[path]['nodes'][node]['settings']['mappedAgents'][indexMappedAgents]['interfaceMappings'][i]['nodeInterface'] == 'n6' and enablePassthru==True:
                                        newConfig[path]['nodes'][node]['settings']['mappedAgents'][indexMappedAgents]['interfaceMappings'][i]['agentInterface'] = agentsDict[node][1]
                                        newConfig[path]['nodes'][node]['settings']['mappedAgents'][indexMappedAgents]['interfaceMappings'][i]['agentInterfaceMac'] = agentsDict[node][2]
                                    elif node == 'ran' and newConfig[path]['nodes'][node]['settings']['mappedAgents'][indexMappedAgents]['interfaceMappings'][i]['nodeInterface'] == 'passthroughDevice' and enablePassthru==False:
                                        newConfig[path]['nodes'][node]['settings']['mappedAgents'][indexMappedAgents]['interfaceMappings'][i]['agentInterface'] = 'none'
                                        newConfig[path]['nodes'][node]['settings']['mappedAgents'][indexMappedAgents]['interfaceMappings'][i]['agentInterfaceMac'] = 'none'
                                    elif node in ['upf', 'ran', 'smf'] and newConfig[path]['nodes'][node]['settings']['mappedAgents'][indexMappedAgents]['interfaceMappings'][i]['nodeInterface'] in ['n6','passthroughDevice'] and enablePassthru==False:
                                        newConfig[path]['nodes'][node]['settings']['mappedAgents'][indexMappedAgents]['interfaceMappings'][i]['agentInterface'] = 'none'
                                        newConfig[path]['nodes'][node]['settings']['mappedAgents'][indexMappedAgents]['interfaceMappings'][i]['agentInterfaceMac'] = 'none'
                                    else:
                                        newConfig[path]['nodes'][node]['settings']['mappedAgents'][indexMappedAgents]['interfaceMappings'][i]['agentInterface'] = agentsDict[node][1]
                                        newConfig[path]['nodes'][node]['settings']['mappedAgents'][indexMappedAgents]['interfaceMappings'][i]['agentInterfaceMac'] = agentsDict[node][2]                
                else:
                    if node == "dn" or newConfig['configData'][path]['nodes'][node]['settings']['enable'] == True:
                        try:
                            newConfig['configData'][path]['nodes'][node]['settings']['mappedAgents'][indexMappedAgents]['agentId'] = agentsDict[node][0]
                        except IndexError as e:
                            self.logger.info("ERROR! Index of out range! This usually hapens when the config has no previously assigned agents and the mappedAgents parameter is empty. Check below to see if this is the case.")
                            raise IndexError
                        for i in range(len(newConfig['configData'][path]['nodes'][node]['settings']['mappedAgents'][indexMappedAgents]['interfaceMappings'])):
                            if applicationInterface is None:
                                # TODO workaround for a bug
                                if node in ['upf','ran', 'smf'] and newConfig['configData'][path]['nodes'][node]['settings']['mappedAgents'][indexMappedAgents]['interfaceMappings'][i]['nodeInterface'] in ['n6','passthroughDevice']:
                                    newConfig['configData'][path]['nodes'][node]['settings']['mappedAgents'][indexMappedAgents]['interfaceMappings'][i]['agentInterface'] = 'none'
                                    newConfig['configData'][path]['nodes'][node]['settings']['mappedAgents'][indexMappedAgents]['interfaceMappings'][i]['agentInterfaceMac'] = 'none'
                                else:
                                    newConfig['configData'][path]['nodes'][node]['settings']['mappedAgents'][indexMappedAgents]['interfaceMappings'][i]['agentInterface'] = agentsDict[node][1]
                                    newConfig['configData'][path]['nodes'][node]['settings']['mappedAgents'][indexMappedAgents]['interfaceMappings'][i]['agentInterfaceMac'] = agentsDict[node][2]
                            else:
                                if newConfig['configData'][path]['nodes'][node]['settings']['mappedAgents'][indexMappedAgents]['interfaceMappings'][i]['nodeInterface'] == applicationInterface:
                                    # TODO workaround for a bug
                                    if node == 'upf' and newConfig['configData'][path]['nodes'][node]['settings']['mappedAgents'][indexMappedAgents]['interfaceMappings'][i]['nodeInterface'] == 'n6' and enablePassthru==True:
                                        newConfig['configData'][path]['nodes'][node]['settings']['mappedAgents'][indexMappedAgents]['interfaceMappings'][i]['agentInterface'] = agentsDict[node][1]
                                        newConfig['configData'][path]['nodes'][node]['settings']['mappedAgents'][indexMappedAgents]['interfaceMappings'][i]['agentInterfaceMac'] = agentsDict[node][2]
                                    elif node == 'ran' and newConfig['configData'][path]['nodes'][node]['settings']['mappedAgents'][indexMappedAgents]['interfaceMappings'][i]['nodeInterface'] == 'passthroughDevice' and enablePassthru==False:
                                        newConfig['configData'][path]['nodes'][node]['settings']['mappedAgents'][indexMappedAgents]['interfaceMappings'][i]['agentInterface'] = 'none'
                                        newConfig['configData'][path]['nodes'][node]['settings']['mappedAgents'][indexMappedAgents]['interfaceMappings'][i]['agentInterfaceMac'] = 'none'
                                    elif node in ['upf', 'ran', 'smf'] and newConfig['configData'][path]['nodes'][node]['settings']['mappedAgents'][indexMappedAgents]['interfaceMappings'][i]['nodeInterface'] in ['n6','passthroughDevice'] and enablePassthru==False:
                                        newConfig['configData'][path]['nodes'][node]['settings']['mappedAgents'][indexMappedAgents]['interfaceMappings'][i]['agentInterface'] = 'none'
                                        newConfig['configData'][path]['nodes'][node]['settings']['mappedAgents'][indexMappedAgents]['interfaceMappings'][i]['agentInterfaceMac'] = 'none'
                                    else:
                                        newConfig['configData'][path]['nodes'][node]['settings']['mappedAgents'][indexMappedAgents]['interfaceMappings'][i]['agentInterface'] = agentsDict[node][1]
                                        newConfig['configData'][path]['nodes'][node]['settings']['mappedAgents'][indexMappedAgents]['interfaceMappings'][i]['agentInterfaceMac'] = agentsDict[node][2]
            except Exception as e:
                self.logger.info("agentsDict este: {0}".format(agentsDict))
                self.logger.info("newConfig este: {0}".format(newConfig))
                self.logger.info("Error is: %s " % e)
            agentsInfo = self.getAgentsInfo2()
            ## in the for below, I am trying to match the agentId from agentsDict, with his IP
            for agentInfo in agentsInfo:
                if agentsDict[node][0] == agentInfo['id']:
                    agentIP = agentInfo['IP']
            inter = self.getAgentInterfaces(agentsInfo, agentIP)
            for cnt in range(len(inter)):
                if agentIP in d:
                    if inter[cnt]['Name'] not in d[agentIP]:
                        d[agentIP].append(inter[cnt]['Name'])  # if interface not in dict[agent], add it
                else:
                    d[agentIP] = []        # if agent is not in dict, add it
                    d[agentIP].append(inter[cnt]['Name'])

            # enablePerUEstats = True
            # if enablePerUEstats:
            #     newConfig['configData'][path]['globalSettings']['advancedStats']['enablePerSessionStats'] = True
            for key, value in kwargs:
                if 'enablePerUEstats' in key:
                    enablePerUEstats = value
                    if enablePerUEstats:
                        if archive:
                            newConfig[path]['globalSettings']['advancedStats']['enablePerSessionStats'] = True
                        else:
                            newConfig['configData'][path]['globalSettings']['advancedStats']['enablePerSessionStats'] = True

        for agentIP in d:
            networkSettings[self.getAgentNodeID(agentsInfo, agentIP)] = d[agentIP]   # create a dict with keys as agentNodeID and interfaces list as elements        
        return newConfig, networkSettings


    def RemapMultiAgents(self, configToModify, agentsDict, topology="full-core"):
        import copy
        newConfig = copy.deepcopy(configToModify)
        path = "Config"
        if topology == "upf-isolation":
            path = "UpfIsolationConfig"

        for node in agentsDict:
            for k in range(len(newConfig['configData'][path]['nodes'][node]['settings']['mappedAgents'])):
                newConfig['configData'][path]['nodes'][node]['settings']['mappedAgents'][k]['agentId'] = agentsDict[node][k][0]
                for i in range(len(newConfig['configData'][path]['nodes'][node]['settings']['mappedAgents'][k]['interfaceMappings'])):
                    newConfig['configData'][path]['nodes'][node]['settings']['mappedAgents'][k]['interfaceMappings'][i]['agentInterface'] = agentsDict[node][k][1]
                    newConfig['configData'][path]['nodes'][node]['settings']['mappedAgents'][k]['interfaceMappings'][i]['agentInterfaceMac'] = agentsDict[node][k][2]
        return newConfig

    def getStats(self, statName, sessionID, testId=None):
        if testId == None:
            testId = self.getTestId(sessionID)
        response = self.get('/api/v2/results/{0}/stats/{1}'.format(testId, statName), headers=self.headers)
        self.testcase.assertEquals(response.status_code, 200)
        col = {}
        statList = []

        if response.json()['columns'][0] == "timestamp":
            try:
                for i in range(len(response.json()['columns']) - 1):
                    n = response.json()['columns'][i+1]
                    for j in range(len(response.json()['snapshots'])):
                        statList.append(float(response.json()['snapshots'][j]['values'][0][i+1]))
                    col[n] = statList
                    statList = []

                return col
            except:
                print("Exception raised: No stats available for {}. Test didn't run as expected".format(statName))
                raise
        
        elif response.json()['columns'][0] == "agentip.keyword" or response.json()['columns'][0] == "Agent IP" or response.json()['columns'][0] == "agentindex":  # in some stats agentindex is Agent IP
            try:
                for i in range(len(response.json()['columns'])-2):
                    n = response.json()['columns'][i+2]

                    if len(response.json()['snapshots']) == 1:
                        for j in range(len(response.json()['snapshots'][0]['values'])):
                            try:    # sometimes can be publisher.keyword and will fail when cast to float
                                statList.append(float(response.json()['snapshots'][0]['values'][j][i+2]))
                            except:
                                pass
                    else:
                        for j in range(len(response.json()['snapshots'])):
                            try:
                                for k in range(len(response.json()['snapshots'][j]['values'])):
                                    statList.append(float(response.json()['snapshots'][j]['values'][k][i+2]))
                            except:
                                pass
                    col[n] = statList
                    statList = []
                return col
            except:
                print("Exception raised: No stats available for {}. Test didn't run as expected".format(statName))
                raise

        else:
            try:
                for i in range(len(response.json()['columns'])-1):
                    n = response.json()['columns'][i+1]
                    for j in range(len(response.json()['snapshots'][0]['values'])):
                        statList.append(float(response.json()['snapshots'][0]['values'][j][i+1]))
                    col[n] = sum(statList)
                    statList = []
                return col
            except:
                try:
                    for i in range(len(response.json()['columns'])-2):
                        n = response.json()['columns'][i+2]
                        for j in range(len(response.json()['snapshots'][0]['values'])):
                            statList.append(float(response.json()['snapshots'][0]['values'][j][i+2]))
                        col[n] = sum(statList)
                        statList = []
                    return col
                except:
                    print("Exception raised: No stats available for {}. Test didn't run as expected".format(statName))
                    raise

    def getNoTimestampStats(self, statName, sessionID, testId=None):
        if testId == None:
            testId = self.getTestId(sessionID)
        response = self.get('/api/v2/results/{0}/stats/{1}'.format(testId, statName), headers=self.headers)
        self.testcase.assertEquals(response.status_code, 200)
        col = {}
        statList = []

        try:
            for i in range(len(response.json()['snapshots'][0]['values'])):
                col = {}
                for j in range(len(response.json()['columns'])):
                    col[response.json()['columns'][j]] = response.json()['snapshots'][0]['values'][i][j]
                statList.append(col)

            return statList
        except:
            self.logger.info("Exception raised: No stats available for {}. Test didn't run as expected".format(statName))
            raise

    
    def checkFullcoreStats(self, sessionID, checkRates=True):
        failedstatsList = {'Fullcoreoverview_NGSetup': 'NG Setup Failure Rx', # checked
                           'Fullcorengran_NGRANPDUSessionestablishment':  'PDU Session Establishment Failed', #checkd
                           #split the failures list stats in 2: Tx and Rx
                           'Fullcorengran_NGRANRejectRxandFailureRx':['PDU Session Release Reject Rx', 'Registration Reject Rx', 'Path Switch Request Failure Rx', 'Service Reject Rx'], #checked
                           'Fullcorengran_NGRANRejectTxandFailureTx':['Security Mode Reject Tx','Initial Context Setup Failure Tx'],
                           'Fullcorengran_NGRANTotalHandover':'Total Handover Failed', 
                           'Fullcorengran_NGRANXnHandover':'Xn Handover Failed'}
        GreaterThanZeroStatList = {'Fullcoreoverview_RegisteredAttachedUE': 'UEs Registered', 
                            'Fullcorengran_NGRANPDUSessionestablishment': ['PDU Session Establishment Initiated', 'PDU Session Establishment Succeeded'], 
                            'Fullcorengran_NGRANRegistrationprocedure': ['Registration Initiated', 'Registration Succeeded']}
        InitSuccstatList = {'Fullcorengran_NGRANRegistrationprocedure': ['Registration Initiated', 'Registration Succeeded'], 
                            'Fullcorengran_NGRANNGSetupprocedure': ['NG Setup Initiated','NG Setup Succeeded'],
                            'Fullcorengran_NGRANEnterIdleprocedure': ['Enter Idle Initiated', 'Enter Idle Succeeded'],
                            'Fullcorengran_NGRANPagingstatistics':['Paging Initiated','Paging Succeeded'],
                            'Fullcorengran_NGRANTotalHandover': ['Total Handover Initiated','Total Handover Succeeded'], 
                            # PDU Session Modification UE originated Initiated is not in UI
                            #'Fullcorengran_NGRANPDUSessionmodificationmessages':['PDU Session Modification UE originated Initiated','PDU Session Modification UE originated Succeeded'],
                            'Fullcorengran_NGRANXnHandover': ['Xn Handover Initiated','Xn Handover Succeeded'], 
                            'Fullcorengran_NGSetup': ['NG Setup Response Rx','NG Setup Request Tx'],
                            'Fullcorengran_NGRANInitialContextSetupmessages':['Initial Context Setup Response Tx','Initial Context Setup Request Rx'],
                            'Fullcoreamf_AMFRegistrationprocedure': ['Registration Initiated','Registration Succeeded'], 
                            'Fullcoreamf_AMFDeregistrationprocedure':['Deregistration Initiated','Deregistration Succeeded'], 
                            'Fullcoresmf_SMFprocedures':['Create SM Context Initiated', 'Create SM Context Succeeded'], 
                            'Fullcoresmf_SMFPFCPSetup': ['PFCP Setup Initiated','PFCP Setup Succeeded'], 
                            'Fullcoresmf_SMFPFCPRelease': ['PFCP Release Initiated','PFCP Release Succeeded'], 
                            'Fullcoreupf_UPFdataprocedures':['Downlink Data Initiated','Downlink Data Succeeded']}
        
        SBIstatsList = ['Fullcoreoverview_SBIResponseCodes',
                       'Fullcoresbi_HTTPResponseSummary',
                       'Fullcoresbi_NamfResponseSummary',
                       'Fullcoresbi_NsmfResponseSummary',
                       'Fullcoresbi_NausfResponseSummary']

        RatesStatsList = {'Fullcoreoverview_ProcedureRates': [['Initial Registration Initiated/s', 'Initial Registration Succeeded/s'],['Deregistration Initiated/s','Deregistration Succeeded/s'],
                ['Enter Idle Initiated/s','Enter Idle Succeeded/s'], ['Total Handover Initiated/s','Total Handover Succeeded/s'],
                ['Service Request Initiated/s','Service Request Succeeded/s'],['Paging Initiated/s','Paging Succeeded/s'], 
                 ['PDU Session Modification UE originated Initiated/s','PDU Session Modification UE originated Succeeded/s']],
                #  'Fullcoreoverview_N2Messages':[['Initial Context Setup Request Rx/s','Initial Context Setup Response Tx/s'],
                # ['PDU Session Resource Release Response Tx/s','PDU Session Resource Release Command Rx/s'], ['UE Context Release Command Rx/s',
                #  'UE Context Release Complete Tx/s']], 
                 'Fullcoreoverview_N1Messages':[['Authentication Request Rx/s','Authentication Response Tx/s'],['Security Mode Command Rx/s',
                 'Security Mode Complete Tx/s'], ['PDU Session Establishment Request Tx/s',
                 'PDU Session Establishment Accept Rx/s'], ['PDU Session Release Command Rx/s','PDU Session Release Complete Tx/s']]
                }

        testId = self.getTestId(sessionID)

        if checkRates == True:
            for key in RatesStatsList:
                stats = self.getStats(key, sessionID, testId)
                for item in RatesStatsList[key]:
                    #print(item[0],item[1],self.getAvgNonZeroStat(stats[item[0]]),self.getAvgNonZeroStat(stats[item[1]]))
                    self.testcase.assertAlmostEqual(self.getAvgNonZeroStat(stats[item[0]]), self.getAvgNonZeroStat(stats[item[1]]), delta=1, 
                                                    msg='{} != {}'.format(item[0],item[1]))
                        

        for item in SBIstatsList:
            stats = self.getStats(item, sessionID, testId)
            for key in stats:
                if type(stats[key]) is list:
                    if key == '2xx':
                        self.testcase.assertGreater(max(stats[key]), 0, '{}-{} is not greater than 0'.format(item,key))
                    else:
                        self.testcase.assertEqual(max(stats[key]), 0, '{}-{} is not 0'.format(item,key))
                else:
                    if key == '2xx':
                        self.testcase.assertGreater(int(stats[key]), 0, '{}-{} is not greater than 0'.format(item,key))
                    else:
                        self.testcase.assertEqual(int(stats[key]), 0, '{}-{} is not 0'.format(item,key))
        
        for key in failedstatsList:
            stats = self.getStats(key, sessionID, testId)
            if type(failedstatsList[key]) is list:
                for item in failedstatsList[key]:
                    self.testcase.assertEqual(max(stats[item]), 0, '{} is not 0'.format(item))
            else:
                self.testcase.assertEqual(max(stats[failedstatsList[key]]), 0, '{} is not 0'.format(key))
        
        for key in GreaterThanZeroStatList:
            stats = self.getStats(key, sessionID, testId)
            if type(GreaterThanZeroStatList[key]) is list:
                for item in GreaterThanZeroStatList[key]:
                    self.testcase.assertGreater(max(stats[item]), 0, '{} is not greater than 0'.format(item))

            else:
                self.testcase.assertGreater(max(stats[GreaterThanZeroStatList[key]]), 0, '{} is not greater than 0'.format(key))
        
        for key in InitSuccstatList:
            stats = self.getStats(key, sessionID, testId)
            self.testcase.assertEqual(max(stats[InitSuccstatList[key][0]]), max(stats[InitSuccstatList[key][1]]), 
                                    '{} is not equal with {}'.format(InitSuccstatList[key][0], InitSuccstatList[key][1]))

    def checkSBATesterStats(self, sessionID):
        statsList = ['Sbatesterudmtester_NausfUEAuthenticationProcedure', 
                    'Sbatesterudmtester_NudmSDMAMFDeregisterProcedure', 
                    'Sbatestersmpolicies_NpcfSMPolicyControlGETProcedure', 
                    'Sbatesterampolicies_NpcfAMPolicyControlGETProcedure', 
                    'Sbatesterampolicies_NpcfAMPolicyControlCREATEProcedure', 
                    'Sbatestersmpolicies_NpcfSMPolicyControlCREATEProcedure',
                    'Sbatestersmpolicies_NpcfSMPolicyControlUPDATEProcedure', 
                    'Sbatesterampolicies_NpcfAMPolicyControlUPDATEProcedure', 
                    'Sbatestersmpolicies_NpcfSMPolicyControlDELETEProcedure', 
                    'Sbatesterampolicies_NpcfAMPolicyControlDELETEProcedure']

        InitSuccstatList = {'Sbatesterudmtester_NudmSDMAMFInitialandMobilityRegistrationProcedure':['AMF Complete Registrations Initiated', 'AMF Complete Registrations Succeeded']}

        GreaterThanZeroStatList = {'Sbatestertcpconnections_TCPconnectionsstatus':'Active TCP Connections'}

        testId = self.getTestId(sessionID)

        for key in GreaterThanZeroStatList:
            stats = self.getStats(key, sessionID, testId)
            self.testcase.assertGreater(max(stats[GreaterThanZeroStatList[key]]), 0, '{} is not greater than 0'.format(key))

        for item in statsList:
            stats = self.getStats(item, sessionID, testId)
            initSucc = []

            for key in stats.keys():
                if 'Failed' in key:
                    self.testcase.assertEqual(max(stats[key]), 0, '{} is not 0'.format(key))
                if 'TimedOut' in key:
                    self.testcase.assertEqual(max(stats[key]), 0, '{} is not 0'.format(key))
                if 'Initiated' in key:
                    initSucc.append(key)
                if 'Succeeded' in key:
                    initSucc.append(key)

            self.testcase.assertEqual(max(stats[initSucc[0]]), max(stats[initSucc[1]]), '{} is not equal with {}'.format(initSucc[0],initSucc[1]))

        for key in InitSuccstatList:
            stats = self.getStats(key, sessionID, testId)
            self.testcase.assertEqual(max(stats[InitSuccstatList[key][0]]), max(stats[InitSuccstatList[key][1]]), 
                                        '{} is not equal with {}'.format(InitSuccstatList[key][0], InitSuccstatList[key][1]))

    def getRawStats(self, statName, sessionID, testID=None):
        if testID == None:
            testID = self.getTestId(sessionID)
        response = self.get('/api/v2/results/{0}/stats/{1}'.format(testID, statName), headers=self.headers)
        return response.json()

    def generateStatsCSV(self, sessionID, path, csvsToGet):
        nullStats = []

        testID = self.getTestId(sessionID)
        if csvsToGet[0] == '*':
            response = self.get('/api/v2/results/{0}/stats/'.format(testID), headers=self.headers).json()
            csvsToGet = []
            for value in response:
                csvsToGet.append(value['name'])
        for stat in csvsToGet:
            stats = self.getRawStats(stat, sessionID, testID)

            if 'snapshots' in stats.keys():
                if stats['snapshots'] is not None:
                    columns = stats['columns']
                    #this is to delete the filter property from CSV
                    if columns[0] == 'filter':
                        columns.pop(0)
                    with open('{}/{}.csv'.format(path, stat), 'w+', newline='') as csvFile:
                        csvwriter = csv.writer(csvFile)
                        if len(stats['snapshots'][0]) == 1 and columns[1]=="1xx":
                            columns_list = ['timestamp']
                            data_uri_list = ['1']
                            for i in range (len(stats['snapshots'][0]['values'])):
                                for j in range(1, len(stats['snapshots'][0]['values'][0])):
                                    if j < 6 :
                                        columns = stats['snapshots'][0]['values'][i][0]+' '+str(j)+'xx'
                                        columns_list.append(columns)
                                    else: 
                                        columns = stats['snapshots'][0]['values'][i][0]+' Requests'
                                        columns_list.append(columns)
                            csvwriter.writerow(columns_list)
                            for k in range (len(stats['snapshots'][0]['values'])):
                                for m in range (1, len(stats['snapshots'][0]['values'][0])):
                                    data_uri = stats['snapshots'][0]['values'][k][m]
                                    data_uri_list.append(data_uri)
                            csvwriter.writerow(data_uri_list)
                        elif len(stats['snapshots'][0]) == 1 and columns[1]!="1xx":
                            if columns[0]!="timestamp":
                                columns[0] = "timestamp"
                            csvwriter.writerow(columns)
                            data = [stats['snapshots'][0]['values'][i] for i in range(len(stats['snapshots'][0]['values']))]
                            csvwriter.writerows(data)
                        else:                           
                            csvwriter.writerow(columns)
                            data = [stats['snapshots'][i]['values'][0] for i in range(len(stats['snapshots']))]
                            for value in data:
                                #this is to delete the filter value from CSV
                                if value[0] in ["NGRAN", "UPF"]:
                                    value.pop(0)
                            csvwriter.writerows(data)
                else:
                    nullStats.append(stat)
            else:
                nullStats.append(stat)
        
        if len(nullStats) > 0:
            self.logger.info("nullStats is %s", nullStats)

    def getResults(self, sessionID, path, wait=40, statusCode=202, perSessionStats=False):
        testID = self.getTestId(sessionID)
        payload = {'includeDiagnostics': 'false'}

        response = self.post('/api/v2/results/{0}/operations/export'.format(testID), data=payload, headers=self.headers)
        self.testcase.assertEquals(response.status_code, statusCode)

        operation_url = '/api/v2/results/{0}/operations/generate-csv/{1}'.format(testID, response.json()['id'])

        while wait > 0:      
            state = self.get(operation_url, headers=self.headers)
            self.logger.debug(pformat(state.json()))

            if state.json()['state'] == 'SUCCESS':
                archive = self.get(state.json()['resultUrl'], headers=self.headers)
                break

            if state.json()['state'] == 'ERROR': 
                self.testcase.assertTrue(False, 'Could not get the results archive')

            wait -= 5
            time.sleep(5)

        else:
            self.testcase.assertTrue(False, 'Failed to download the results archive')

        filename = '{0}/{1}'.format(path, archive.headers['Content-Disposition'].split("=")[1])
        os.makedirs(os.path.dirname(filename), exist_ok=True)

        with open(filename, 'wb') as f:
            f.write(archive.content)

        if perSessionStats:
            return filename
        else:
            return len(archive.content)

    def getCapturesLogs(self, sessionID, path, wait=40, statusCode=202):
        testID = self.getTestId(sessionID)

        response = self.post('/api/v2/results/{0}/operations/export-results'.format(testID), headers=self.headers)
        self.testcase.assertEquals(response.status_code, statusCode)

        operation_url = '/api/v2/results/{0}/operations/generate-results/{1}'.format(testID, response.json()['id'])

        while wait > 0:      
            state = self.get(operation_url, headers=self.headers)
            self.logger.debug(pformat(state.json()))

            if state.json()['state'] == 'SUCCESS':
                archive = self.get(state.json()['resultUrl'], headers=self.headers)
                break

            if state.json()['state'] == 'ERROR': 
                self.testcase.assertTrue(False, 'Could not get the captures/logs archive')

            wait -= 5
            time.sleep(5)

        else:
            self.testcase.assertTrue(False, 'Failed to download the capture')
        
        filename = '{0}/{1}'.format(path, archive.headers['Content-Disposition'].split("=")[1]).replace('"','')
        os.makedirs(os.path.dirname(filename), exist_ok=True)

        with open(filename, 'wb') as f:
            f.write(archive.content)

        return filename

    def getCapturesSizes(self, filename):
        sizes = {}
        folder = filename.split(".")[0]
        zip=zipfile.ZipFile(filename)
        zip.extractall(folder)

        files=os.listdir(folder)
        for f in files:
            if f.endswith('.zip'):
                filePath = folder + '/' + f
                zip=zipfile.ZipFile(filePath)
                folderPath = filePath.split(".")[0]
                zip.extractall(folderPath)
        
        for root, dirs, files in os.walk(folder):
            for f in files:
                if f.endswith(".pcap"):
                    full_path = os.path.join(root, f)
                    sizes[full_path] = os.stat(full_path).st_size

        return sizes

    def getPerSessionStatsCsvs(self, filename, agentIP):
        sizes = {}
        folder = filename.split(".")[0]
        zip=zipfile.ZipFile(filename)
        zip.extractall(folder)
        files=os.listdir(folder)
        perSessionStatsFilename = 'agent-' + agentIP + '-csv.zip'
        for f in files:
            if f.startswith(perSessionStatsFilename):
                filePath = folder + '/' + f
                zip=zipfile.ZipFile(filePath)
                folderPath = filePath.split(".")[0]
                zip.extractall(folderPath)
        for root, dirs, files in os.walk(folder):
            for f in files:
                if f.startswith('per-ue'):
                    full_path = os.path.join(root, f)
                    sizes[full_path] = os.stat(full_path).st_size
        return sizes

    def getPDFreport(self, sessionID, wait=40, statusCode=202):
        testID = self.getTestId(sessionID)

        response = self.post('/api/v2/results/{0}/operations/generate-pdf'.format(testID), headers=self.headers)
        self.testcase.assertEquals(response.status_code, statusCode)

        operation_url = '/api/v2/results/{0}/operations/generate-pdf/{1}'.format(testID, response.json()['id'])

        while wait > 0:      
            state = self.get(operation_url, headers=self.headers)
            self.logger.debug(pformat(state.json()))

            if state.json()['state'] == 'SUCCESS':
                pdfReport = self.get(state.json()['resultUrl'], headers=self.headers)
                break

            if state.json()['state'] == 'ERROR': 
                self.testcase.assertTrue(False, 'ERROR: Could not get the pdf report')

            wait -= 5
            time.sleep(5)

        else:
            self.testcase.assertTrue(False, 'Failed to download the pdf report. Try increasing the wait time.')

        filename = '{0}'.format(pdfReport.headers['Content-Disposition'].split("=")[1].replace('"',''))

        with open(filename, 'wb') as f:
            f.write(pdfReport.content)
    
        return filename

    def export_all_configs(self, wait=180, statusCode=202):
        response = self.post('/api/v2/configs/operations/exportAll', headers=self.headers, data={"configIds":[]})
        self.testcase.assertEquals(response.status_code, statusCode)

        operation_url = '/api/v2/configs/operations/exportAll/{0}'.format(response.json()['id'])

        while wait > 0:      
            state = self.get(operation_url, headers=self.headers)
            self.logger.debug(pformat(state.json()))

            if state.json()['state'] == 'SUCCESS':
                configs = self.get(state.json()['resultUrl'], headers=self.headers)
                break

            if state.json()['state'] == 'ERROR': 
                self.testcase.assertTrue(False, 'ERROR: Could not download the configs')

            wait -= 5
            time.sleep(5)

        else:
            self.testcase.assertTrue(False, 'Could not download the configs. Try increasing the wait time.')


        filename = "configs/"+'{0}'.format(configs.headers['Content-Disposition'].split("=")[1].replace('"',''))

        with open(filename, 'wb') as f:
            f.write(configs.content)
    
        return filename

    def exportConfig(self, configID, statusCode=200):
        self.headers['accept'] = 'application/zip'
        response = self.get('/api/v2/configs/{}?include=all&resolveDependencies=true'.format(configID), headers=self.headers)
        self.testcase.assertEquals(response.status_code, statusCode)

        filename = "configs/"+'{0}'.format(response.headers['Content-Disposition'].split("=")[1].replace('"','').replace(':','_'))

        with open(filename, 'wb') as f:
            f.write(response.content)
    
        return filename

    def assignAgents(self, sessionID, agentsDict):
        """
        four methods to assign agent to  5G nodes:
        1. agentsDict[node] = self.lizardAgent1 
            it will use the agent's first test interface

        2. agentsDict[node] = [{'agent': self.lizardAgent2, 'n3': 'ens160', 'n4': 'ens160', 'n6': 'none' , 'n9': 'ens160'}]
            it will assign 'agent' to the node as described in the dict

        3. agentsDict[node] = [(self.lizardAgent1, 'ens192')]
            it will use the exact test interface (ens192)
        
        4. agentsDict[node] = [self.lizardAgent1, self.lizardAgent2]
           agentsDict[node] = [(self.lizardAgent2, 'ens192'),(self.lizardAgent1, 'ens160')]
            this is used to assign multiple agents on every node. It will use the first interface.
            Can be used also as tuple: assign first agent with a specific interface, assign second with specific interface.

        """
        def __create_Mappings(agentsInfo, agentIP, testInterface, networkSettings):
            AgentNodeID = self.getAgentNodeID(agentsInfo, agentIP)
            if AgentNodeID not in networkSettings:      # check if agent already exist. If not, create key.
                networkSettings[AgentNodeID] = []
            if node == 'dn' or path[node]['settings']['enable'] == True:   # check if node is enabled
                for interface in defaultDict[node]:                 # go through each node interface and create the dict
                    agentInterface = testInterface
                    agentInterfaceMac = self.getInterfaceMAC(agentsInfo, agentIP, testInterface)
                    if interface == 'passthroughDevice' or (node == 'upf' and interface == 'n6'):    # check for passthrough on ran and n6 on upf
                        agentInterface = "none"
                        agentInterfaceMac = "none"
                    interfaceMappings.append({
                                            'agentInterface': agentInterface, \
                                            'agentInterfaceMac': agentInterfaceMac, \
                                            'nodeInterface': interface
                                            })
                    if agentInterface not in networkSettings[AgentNodeID] and agentInterface != 'none':
                        networkSettings[AgentNodeID].append(agentInterface)
            
            return AgentNodeID, interfaceMappings, networkSettings[AgentNodeID]

        # each 5G node with its interfaces. This can suffer changes between releases
        defaultDict = { 
                        'amf': ['n2', 'namf', 'n26'], 'ausf': ['nausf'], 'dn': ['n6'], 'eir': ['n5geir'], \
                        'mme': [], 'nrf': ['nnrf'], 'nssf': ['nnssf'], 'pcf': ['npcf','rx'], \
                        'ran': ['n2', 'n3', 'passthroughDevice', 's1u', 'n26', 's6a', 's5c', 's5u', 's11','s1'], 
                        'sgw': [], 'smf': ['n4', 'nsmf', 's5c', 's11'], 'smsf': ['nsmsf'], 'udm': ['nudm','s6a'], 'udr': ['nudr'], \
                        'upf': ['n3', 'n4', 'n6', 'n9'], 'ims': ['n6','rx']
                        }

        config = self.getSessionConfig(sessionID)
        topology = self.getTopologyFromSessionConfig(config)

        path = config[topology]['nodes']

        agentsInfo = self.getAgentsInfo()
        networkSettings = {}

        for node in agentsDict:         # go through each node
            mappedAgents = []
            if type(agentsDict[node]) is not list:                  # if not list, convert to list. This helps multi agent support
                agentsDict[node] = agentsDict[node].split("-")
            for agent in agentsDict[node]:                          # go through each agent.
                interfaceMappings = []
                mappedDict = {}
                if type(agent) is dict:       #[{'agent': self.lizardAgent2, 'n3': 'ens160', 'n4': 'ens160', 'n6': 'none' , 'n9': 'ens160'}]
                    agentIP = agent['agent']
                    AgentNodeID = self.getAgentNodeID(agentsInfo, agentIP)
                    if AgentNodeID not in networkSettings:      # check if agent already exist. If not, create key.
                        networkSettings[AgentNodeID] = []
                    if node == 'coreSim':
                        settings = 'basicSettings'
                        status = False
                    else:
                        settings = 'settings'
                        status = True
                    if path[node][settings]['enable'] == status:   # check if node is enabled
                        del agent['agent']
                        nodeInterfaces = agent
                        
                        for interface in nodeInterfaces:
                            if nodeInterfaces[interface] == 'none':
                                agentInterfaceMac = 'none'
                            else:
                                agentInterfaceMac = self.getInterfaceMAC(agentsInfo, agentIP, nodeInterfaces[interface])
                            interfaceMappings.append({
                                            'agentInterface': nodeInterfaces[interface], \
                                            'agentInterfaceMac': agentInterfaceMac, \
                                            'nodeInterface': interface
                                            })
                            if nodeInterfaces[interface] not in networkSettings[AgentNodeID] and nodeInterfaces[interface] != 'none':
                                networkSettings[AgentNodeID].append(nodeInterfaces[interface])
                            # print(interfaceMappings)
                elif type(agent) is tuple:
                    AgentNodeID, interfaceMappings, networkSettings[AgentNodeID] = __create_Mappings(agentsInfo, agent[0], agent[1], networkSettings)

                else:
                    AgentNodeID, interfaceMappings, networkSettings[AgentNodeID] = __create_Mappings(agentsInfo, agent, \
                                                                                    self.getAgentInterfaces(agentsInfo, agent)[0]['Name'], networkSettings)

                # create list of assigned agents.
                mappedDict = {'agentId': AgentNodeID, 'id': "", "interfaceMappings": interfaceMappings}
                mappedAgents.append(mappedDict)


            if node == 'coreSim':
                path[node]['basicSettings']['mappedAgents'] = mappedAgents
            else:
                path[node]['settings']['mappedAgents'] = mappedAgents

            payload = {node: path[node]}        # use the whole node structure as payload

            response = self.patch('/api/v2/sessions/{}/config/{}/nodes'.format(sessionID,topology.lower() if topology == 'Config' else topology), data=payload)
            self.testcase.assertEqual(response.status_code, 204)


        # print(networkSettings)
        # populate networkSettings with current agents
        updatedNetworkSettings = self.updateNetworkSettings(config, networkSettings, topology, fromSession=1)[topology]['networkSettings']
        # print(updatedNetworkSettings)

        response = self.patch('/api/v2/sessions/{}/config/{}/networkSettings'.format(sessionID,topology.lower() if topology == 'Config' else topology), data=updatedNetworkSettings)
        self.testcase.assertEqual(response.status_code, 204)

    def generateSanityAsserts(self, sessionID, listOfViews, operator = "max", howToBe= "Equal",percentage=10):
        testId = self.getTestId(sessionID)

        for view in listOfViews:
            stats = self.getStats(view,sessionID,testId)
            print(view + " = self.mw.getStats('" + view + "', newSessionID)")
            for stat in stats:
                if howToBe == "Equal":
                    print("self.assert" + howToBe + "(" + operator + "(" + view + "['" + stat + "']), " + str(max(stats[stat])) + ")")
                else:
                    delta = self.getAvgNonZeroStat(stats[stat]) * percentage / 100
                    value = self.getAvgNonZeroStat(stats[stat])
                    print("self.assert" + howToBe + "(" + operator + "(" + view + "['" + stat + "']), " + str(value) + ",delta=" + str(delta) + ")")

class LizardAgent(Requests):
    def __init__(self, logger, testcase=None, host='localhost', port=48484, protocol='https', enablehttp2=True):
        self.testcase = testcase
        self.logger = logger
        self.host = host
        self.port = port
        self.protocol = protocol
        self.process = None
        self.coverage = os.environ.get('COVERAGE') == '1'
        self.builddir = self.coverage and '.build/native-lcov' or '.build/native'
        self.iplist = []
        self.baseurl = '%s://%s:%d' % (self.protocol, self.host, self.port)
        self.httpv2 = enablehttp2
        self.headers = None

    def get_benchmark_value_for_this_machine(self):
        start = time.time()
        temp_time = []
        for i in range(0, 10):
            self.getAllAgents()
        end = time.time()
        temp_time.append(end-start)
        return sum(temp_time)/len(temp_time)

    def restartLizard(self, waitTime, reboot=0):
        if reboot == 0:
            self.logger.info(
                '*Info: Restarting 5GTestService on %s. Waiting for maximum %d seconds' % (self.host, waitTime))
            response = self.post('/api/v1/debug/restart', data=None, headers=self.headers)
            time.sleep(10)
            elapsedTime = 10
        else:
            self.logger.info(
                '*Info: Rebooting 5GTestService machine %s. Waiting for maximum %d seconds' % (self.host, waitTime))
            response = self.post('/api/v1/debug/reboot', data=None, headers=self.headers)
            time.sleep(15)
            elapsedTime = 15
        testResponse = ''
        while elapsedTime < waitTime and testResponse == '':
            try:
                testResponse = self.get('/api/v1/version')
            except ConnectionError as e:
                self.logger.info('*Debug: Exception: %s' % e)
                pass
            time.sleep(5)
            elapsedTime += 5
            self.logger.info('*Debug: waited for %d seconds!' % elapsedTime)
        self.logger.info('*Info: Waited for %d seconds!' % elapsedTime)
        return

    def addIpAddressToInterface(self, interface='eth1', ipAddress='1.32.45.1', prefix=24):
        response = self.get('/api/v1/network/interfaces/' + interface + '/addresses')
        if response.status_code == 200:
            ipAddressJson = {}
            ipAddressJson['addr'] = ipAddress
            ipAddressJson['prefix'] = prefix
            ipAddressJson['scope'] = 'universe'
            response = self.post('/api/v1/network/interfaces/' + interface + '/addresses', data=ipAddressJson, headers=self.headers)
            if response.status_code == 201:
                addressId = response.headers['Location'].split('/')[-1]
                self.iplist.append(addressId)

    def delIpAddressFromInterface(self, addressId, interface='eth1'):
        response = self.get('/api/v1/network/interfaces/' + interface + '/addresses')
        if response.status_code == 200:
            response = self.delete('/api/v1/network/interfaces/' + interface + '/addresses/' + addressId)
            if response.status_code != 204:
                self.logger.error("Cannot delete " + addressId + " IP address")

    def delAllIpAddressAddedFromInterface(self, interface='eth1'):
        response = self.get('/api/v1/network/interfaces/' + interface + '/addresses')
        if response.status_code == 200:
            for ipaddr in self.iplist:
                self.delete('/api/v1/network/interfaces/' + interface + '/addresses/' + ipaddr)
            del self.iplist[:]

    def getAllIpAddressFromInterface(self, interface):
        response = self.get('/api/v1/network/interfaces/' + interface + '/addresses')
        if response.status_code == 200:
            return response.json()
            # return json.loads(response.content)
        else:
            return None

    def getListOfAllAvaiableInterfaces(self):
        response = self.get('/api/v1/network/interfaces')
        if response.status_code == 200:
            return json.loads(response.content)
        else:
            return None

    def getIDOfIP(self, interface, myIP):
        IPList = self.getAllIpAddressFromInterface(interface)
        for IP in IPList:
            if myIP in IP['addr']:
                return IP['id']
                break
        else:
            return None

    def hasApplication(self, application):
        response = self.get('/api/v1/applications')
        self.testcase.assertEquals(response.status_code, 200)
        return application in [app['type'] for app in response.json()]

    def setLogLevel(self, newLogLevel, statusCode=204):
        configJson = {"logLevel": "{}".format(newLogLevel)}
        response = self.patch('/api/v1/debug', configJson)
        self.testcase.assertEquals(response.status_code, statusCode)

    def getLogLevel(self, statusCode=200):
        response = self.get('/api/v1/debug')
        self.testcase.assertEquals(response.status_code, statusCode)
        self.testcase.assertEquals(len(response.json()), 1)
        return response.json()['logLevel']

    def getApplicationConfig(self, application):
        response = self.get('/api/v1/applications/%s/configuration' % application)
        self.testcase.assertEquals(response.status_code, 200)
        return response.json()

    def waitApplicationState(self, application, state, wait=5000):
        while self.getApplicationState(application) != state:
            wait -= 20
            time.sleep(0.02)
            if wait <= 0:
                assert "Application did not configure correctly"
        else:
            return state

    def getApplicationState(self, application):
        response = self.get('/api/v1/applications?no-config')
        self.testcase.assertEquals(response.status_code, 200)
        for app in response.json():
            if app['type'] == application:
                return app['state']
        self.testcase.assertTrue(False, msg='application %s not found' % application)

    def setApplicationConfig(self, application, configJson, statusCode=204, responseMessage=None,
                             responseSubstring=None):
        response = self.put('/api/v1/applications/%s/configuration' % application, configJson)
        try:
            self.testcase.extra_msg = application + ": " + response.json()['detail']
        except:
            self.testcase.extra_msg = application + ": " + response.text
        self.testcase.assertEquals(response.status_code, statusCode)
        if responseMessage is not None:
            self.testcase.assertEquals(responseMessage, response.json()['detail'])
        if responseSubstring is not None:
            self.testcase.assertTrue(responseSubstring in response.json()['detail'])

    def setPython(self, sometext):
        response = self.putText('/api/v1/python', sometext)
        self.testcase.assertEquals(response.content, "")
        self.testcase.assertEquals(response.status_code, 204)

    def setLicensing(self, licenseServer, licenseType='perpetual'):
        response = self.put('/api/v1/licensing', {"serverAddress": licenseServer, "type": licenseType})
        #self.testcase.assertEquals(response.content, "")
        self.testcase.assertEquals(response.status_code, 204)

    def removeApplicationConfig(self, application, statusCode=204, responseMessage=None):
        response = self.delete('/api/v1/applications/%s/configuration' % application)
        if responseMessage is not None:
            self.testcase.assertEquals(response.json()['detail'], responseMessage)
        self.testcase.assertEquals(response.status_code, statusCode)

    def startApplication(self, application, wait=5000, statusCode=204, responseMessage=None):
        response = self.post('/api/v1/applications/%s/operations/start' % application, None, headers=self.headers)
        try:
            self.testcase.extra_msg = application + ": " + response.json()['detail']
        except:
            self.testcase.extra_msg = application + ": " + response.text
        if responseMessage is not None:
            self.testcase.assertEquals(response.json()['detail'], responseMessage)
        self.testcase.assertEquals(response.status_code, statusCode)
        if statusCode == 204:
            if wait == 0:
                return
            while wait > 0:
                state = self.getApplicationState(application)
                if state == 'running':
                    return
                wait -= 20
                time.sleep(0.02)
            self.testcase.assertTrue(False, msg='application %s failed to start (%s)' % (application, state))

    def stopApplication(self, application, wait=5000):
        response = self.post('/api/v1/applications/%s/operations/stop' % application, None, headers=self.headers)
        #self.testcase.assertEquals(response.content, "")
        self.testcase.assertEquals(response.status_code, 204)
        if wait == 0:
            return
        while wait > 0:
            state = self.getApplicationState(application)
            if state == 'configured':
                return
            wait -= 100
            time.sleep(0.1)
        self.testcase.assertTrue(False, msg='application %s failed to stop (%s)' % (application, state))

    def updateStats(self):
        response = self.post('/api/v1/statistics', None, headers=self.headers)
        self.testcase.assertEquals(response.status_code, 204)

    def getStats(self):
        response = self.get('/api/v1/statistics')
        self.testcase.assertEquals(response.status_code, 200)
        stats = {}
        for publisherStats in response.json():
            statNames = stats.setdefault(publisherStats['publisher'], [])
            for statEntry in publisherStats['stats']:
                statNames.append(statEntry['name'])
        return stats

    def clearStats(self):
        response = self.delete('/api/v1/statistics')
        self.testcase.assertEquals(response.status_code, 204)

    def clearLogs(self):
        response = self.delete('/api/v1/debug/logs')
        self.testcase.assertEquals(response.status_code, 204)

    def getStatValues(self, publisher, statusCode=200):
        response = self.get('/api/v1/statistics/%s' % publisher)
        self.testcase.assertEquals(response.status_code, statusCode)
        if statusCode == 200:
            return StatValues(self.testcase, response.json(), publisher)
        else:
            return response.content

    def getStatValuesSameTime(self, response, publisher, statName, statusCode=200):
        self.testcase.assertEquals(response.status_code, statusCode)
        for key in response.json():
            if key['publisher'] == publisher:
                for publisher in key['stats']:
                    if publisher['name'] == statName:
                        return publisher['value']

    def changeCSVLogging(self, action, publisher="all", statusCode=204, responseMessage=None):
        response = self.post('/api/v1/statistics/%s/csv/%s' % (publisher, action), data=None, headers=self.headers)
        self.testcase.assertEquals(response.status_code, statusCode)
        if responseMessage is not None:
            self.testcase.assertEquals(response.json()['detail'], responseMessage)
        return response

    def getCSV(self, publisher, statusCode=200, responseMessage=None):
        response = self.get('/api/v1/statistics/%s/csv' % (publisher))
        self.testcase.assertEquals(response.status_code, statusCode)
        if statusCode != 200 and responseMessage is not None:
            try:
                json = len(response.json()) > 0
            except ValueError:
                json = False
            if json:
                self.testcase.assertEquals(response.json()['detail'], responseMessage)
            else:
                self.testcase.assertEquals(response.content, responseMessage)
        return response

    def downloadCSV(self, publisher, localFile):
        response = self.get('/api/v1/statistics/%s/csv' % publisher, stream=True)
        with open(localFile, 'wb') as f:
            for chunk in response.iter_content(chunk_size=1024):
                if chunk:
                    f.write(chunk)
        return True

    def packetCaptureAction(self, action, statusCode=204, responseMessage=None):
        response = self.post('/api/v1/capture/%s' % (action), data=None, headers=self.headers)
        self.testcase.assertEquals(response.status_code, statusCode)
        if statusCode != 204 and responseMessage is not None:
            self.testcase.assertEquals(response.json()['detail'], responseMessage)
        return response

    def setPacketFilter(self, filter={"value": "-i lo -s 0"}):
        response = self.patch('/api/v1/capture/filter', data=filter)
        self.testcase.assertEquals(response.status_code, 204)
        return response

    def getPacketFilter(self):
        response = self.get('/api/v1/capture/filter')
        self.testcase.assertEquals(response.status_code, 200)
        return response.content

    def getPacketCaptureStatus(self):
        response = self.get('/api/v1/capture/status')
        self.testcase.assertEquals(response.status_code, 200)
        return response.content

    def downloadCaptureFile(self, localFile):
        response = self.get('/api/v1/capture', stream=True)
        with open(localFile, 'wb') as f:
            for chunk in response.iter_content(chunk_size=1024):
                if chunk:
                    f.write(chunk)
        return True

    def disableDPDK(self):
        payload = {"active": True, "dpdk": { "enable": False, "active": False}}
        response = self.patch('/api/v1/network/ixstack', data=payload)
        
        self.testcase.assertEquals(response.status_code, 204)

    def enableDPDK(self):
        payload = {"active": True, "dpdk": { "enable": True, "active": True}}
        response = self.patch('/api/v1/network/ixstack', data=payload)
        
        self.testcase.assertEquals(response.status_code, 204)

    def enableTraffic(self, enable=True, gtpuSourcePort=2152, reservedCores=0):
        payload = {"enable": enable, "gtpuSourcePort": {"start": gtpuSourcePort, "count": 1}, "reservedCores": reservedCores}
        response = self.patch('/api/v1/traffic', data=payload)
        
        self.testcase.assertEquals(response.status_code, 204)

    def addIxstackIP(self, deviceID=0, count=1, macStart="0033FF000001", ipStart='20.0.0.2', ipPrefix=16, code=201):
        payload = {"count": count, "macStart":macStart, "macIncrement": "000000000001", "ipStart":ipStart, "ipPrefix":ipPrefix}
        response = self.post('/api/v1/network/ixstack/devices/{0}/addresses'.format(deviceID), data=payload)

        self.testcase.assertEquals(response.status_code, code)

    def bindToIxStack(self, pci):
        payload = [] 
        payload.append(pci)
        response = self.put('/api/v1/network/ixstack/bind', data=payload)
        
        self.testcase.assertEquals(response.status_code, 204)
    
    def getPCIforIface(self, iface, code=200):
        response = self.get('/api/v1/network/ixstack/devices')
        self.testcase.assertEquals(response.status_code, code)
        found = False
        for interface in response.json():
            try:
                if iface in interface['iface']:
                    return interface['pci']
            except Exception as e:
                pass
        
        if not found:
            for interface in response.json():
                try:
                    if "igb_uio" in interface['driver']:
                        return interface['pci']
                except Exception as e:
                    pass
    '''
    [{'driver': 'e1000', 'iface': 'ens32','mac': '000c298ba814','pci': '0000:02:00.0'},
    {'driver': 'vmxnet3','iface': 'ens160','mac': '000c298ba81e','pci': '0000:03:00.0'},
    {'driver': 'vmxnet3','iface': 'ens192','mac': '000c298ba828','pci': '0000:0b:00.0'}]
    '''

    def getDeviceIDforPCI(self, pci, code=200):
        response = self.get('/api/v1/network/ixstack/devices')
        self.testcase.assertEquals(response.status_code, code)
        found = False
        for interface in response.json():
            try:

                if pci in interface['pci']:
                    return interface['id']
                 
            except Exception as e:
                pass
        
        return "Not found"

    def getDeviceIDforPCIMAC(self, pci, code=200):
        response = self.get('/api/v1/network/ixstack/devices')
        self.testcase.assertEquals(response.status_code, code)
        found = False
        for interface in response.json():
            try:

                if pci in interface['pci']:
                    return interface['mac']
                 
            except Exception as e:
                pass
        
        return "Not found"

    def hardStopLizardEngine (self,application):
        if self.getApplicationState(application) == 'running':
            self.stopApplication(application)
            self.removeApplicationConfig(application)
            self.restartLizard(waitTime=20)
            time.sleep(7)
            self.logger.info("Agent for "+application+" is restarted!")
            
    def prepareLizardToRunVsMW (self, parameters, gatewayIP = None):    
        appPath = "/".join(parameters[3].split('/')[0:3])
        appPath = appPath + "/"+parameters[1]+".json"
        with open(appPath, 'r') as jsonData:
            appConfig = json.load(jsonData)

        for ipToAddOnAgent2 in parameters[2]:
            self.addIpAddressToInterface(interface='ens160', ipAddress=ipToAddOnAgent2, prefix=16)

        if parameters[1]=="sgi-client":
            #gatewayIp = gatewayIP
            #print (gatewayIP)
            remoteIP = appConfig['nodes'][0]['remote']
            routeJson = {
                        "dev": "ens160",
                        "dst": remoteIP,
                        "dst_prefix": 32,
                        "gateway": gatewayIP,
                        "scope": "universe"
                        }
            reqHeaders = self.post(url='/api/v1/network/routes', data = routeJson)
            try:
                location = reqHeaders.headers['Location']
                routeId = location.split('/')[-1]
            except Exception as e:
                print(reqHeaders)
                print(e)

        self.setLicensing(licenseServer="10.38.149.253")
        self.setApplicationConfig(application=parameters[1], configJson=appConfig)
        
    def prepareLizardToRunVsMWDPDK (self, parameters, gatewayIP = None):    
        appPath = "/".join(parameters[3].split('/')[0:3])
        appPath = appPath + "/"+parameters[1]+".json"
        with open(appPath, 'r') as jsonData:
            appConfig = json.load(jsonData)
        '''
        Parameters arata asa:
         ['ipsToAddOnSimulatedAMFforDPDK', 'amf', {'dpdk': {'ens160': ['20.0.2.4', '20.0.2.5']}, 'linux': {'ens192': ['20.0.1.1', '20.0.1.4', '20.0.2.3']}}, 'configs-tiger-mw-regression/irat/iRAT_eps_fallback_VoiceSip_2PDUs_2Flows/iRAT_eps_fallback_VoiceSIp_2PDUs_2Flows.json']
        '''

        for ipToAddOnAgent2 in parameters[2]:
            if "linux" in ipToAddOnAgent2:
                for interface in parameters[2]['linux']:
                    for ip in parameters[2]['linux'][interface]:
                        self.addIpAddressToInterface(interface=interface, ipAddress=ip, prefix=16)
            
            if "dpdk" in ipToAddOnAgent2:
                for interface in parameters[2]['dpdk']:
                    pci = self.getPCIforIface(interface)
                    self.bindToIxStack(pci)
                    self.restartLizard(waitTime=120, reboot=1)
                    deviceID = self.getDeviceIDforPCI(pci)
                    self.enableDPDK()
                    self.enableTraffic(reservedCores=1)
                    self.restartLizard(waitTime=60)
                    for ip in parameters[2]['dpdk'][interface]:
                        self.addIxstackIP(deviceID=deviceID, count=1, macStart="0033FF0"+str(parameters[2]['dpdk'][interface].index(ip))+"0001", ipStart=ip, ipPrefix=16)

        self.setLicensing(licenseServer="10.38.149.253")
        self.setApplicationConfig(application=parameters[1], configJson=appConfig)
        
    def deconfigureLizard (self, parameters):
        try:
            self.stopApplication(parameters[1])
            ipsAdded = self.getAllIpAddressFromInterface(interface='ens160')
            idsToBeRemoved = []
            for ip in ipsAdded:
                    if ip['addr'] in parameters[2]:
                        idsToBeRemoved.append(ip['id'])
            for id in idsToBeRemoved:
                self.delIpAddressFromInterface(addressId=id, interface='ens160')
            self.removeApplicationConfig(parameters[1])
            self.restartLizard(waitTime=20)
            time.sleep(7)
            self.logger.info("Agent for "+parameters[1]+" is restarted!")
        except AssertionError:
            self.logger.info("Couldn't deconfigure lizard. Application %s was already in unconfigured state." % parameters[1])

class StatValues:
    def __init__(self, testcase, values, publisher):
        self.testcase = testcase
        self.publisher = publisher
        self.values = {}
        for statEntry in values:
            self.values[statEntry['name']] = statEntry['value']

    def get(self, name=None):
        if name is None:
            return self.values
        else:
            self.testcase.assertTrue(name in self.values)
            return self.values[name]

    def assertEquals(self, name, value):
        self.testcase.assertTrue(name in self.values,
                                 msg='"%s" not found in publisher "%s". Possible values: %s' % (
                                 name, self.publisher, str(self.values.keys())))
        self.testcase.extra_msg = '%s.%s should equal %d' % (self.publisher, name, value)
        self.testcase.assertEquals(self.get(name), value)

    def assertZero(self, name):
        self.testcase.assertTrue(name in self.values)
        self.testcase.extra_msg = '%s.%s should equal 0' % (self.publisher, name)
        self.testcase.assertEquals(self.get(name), 0)

    def assertNotZero(self, name):
        self.testcase.assertTrue(name in self.values)
        self.testcase.extra_msg = '%s.%s should not equal 0' % (self.publisher, name)
        self.testcase.assertNotEquals(self.get(name), 0)

    def assertGreater(self, name, value):
        self.testcase.assertTrue(name in self.values)
        self.testcase.extra_msg = '%s.%s should be greater than %d' % (self.publisher, name, value)
        self.testcase.assertGreater(self.get(name), value)

    def assertLessEqual(self, name, value):
        self.testcase.assertTrue(name in self.values)
        self.testcase.extra_msg = '%s.%s should be less than or equal to %d' % (self.publisher, name, value)
        self.testcase.assertLessEqual(self.get(name), value)

    def assertAlmostEqual(self, name, value, delta):
        self.testcase.assertTrue(name in self.values)
        self.testcase.extra_msg = '%s.%s should be almost equal to %d (+-%d)' % (self.publisher, name, value, delta)
        self.testcase.assertAlmostEqual(self.get(name), value, delta=delta)


if __name__ == '__main__':
    logger = logging.getLogger('example_logger')
    testcase = TestCaseRemote()
    myTest = MW(logger=logger, testcase=testcase, host='10.38.149.157', port=80, protocol='http')
    # mw = self.newMW(self.host1, self.port1, protocol='http', enablehttp2=True)
    # self.mw.put(url="/api/v2/globalsettings", data={"licenseServer": self.licenseServer}, headers=self.mw.headers)
    #print(myTest)
