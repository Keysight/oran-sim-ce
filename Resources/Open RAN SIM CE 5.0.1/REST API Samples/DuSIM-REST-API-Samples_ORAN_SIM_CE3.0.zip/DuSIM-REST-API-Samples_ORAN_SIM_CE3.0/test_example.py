from base import TestCaseRemote
import unittest
import datetime


class TestMW(TestCaseRemote):

    def __init__(self, *args, **kwargs):
        super(TestMW, self).__init__(*args, **kwargs)
        self.clusterIP = "10.39.32.145"  # UI/MW ip address
        self.Agent1 = "10.39.33.81"  # agent1 ip address used for DUCP
        self.Agent2 = "10.39.32.93"  # agent2 ip address
        self.licenseServer = "10.38.159.144"  # license server
        self.username = 'admin'
        self.password = 'admin'


    def test_dusimSa(self):
        print( "Test DuSIM")
        mw = self.newMW(host=self.clusterIP, licenseServer=self.licenseServer, username=self.username, password=self.password)     # create a mw object
        
        configName = "linux_DUSIM_1UERANGE_10UE_1DU_1CELL_CPlane.zip" # config name found in configs folder
        newSessionID = mw.newSession(configArchive=configName)  # start session using the specified config

    # the following section is used to assign an agent to each simulated node. Skipped this part until line #39 if agents are already assigned to config file
        simulatedNodes = ['ducp', 'duup']   # simulated nodes in the selected config
        agentsDict = {}
        for node in simulatedNodes:   # update all emulated nodes with current agents
            if node == 'ducp':
                agentsDict[node] = [{'agent': self.Agent1, 'F1': 'ens160', 'Kin': 'ens160'}]
            elif node == 'duup':
                agentsDict[node] = [{'agent': self.Agent1, 'F1': 'ens192', 'Kin': 'ens160'}]
            else:
                agentsDict[node] = self.Agent2  # Use second agent for the rest of the nodes
        
        mw.assignAgents(newSessionID, agentsDict)   # assign agents

        mw.changeNetworkSettings(newSessionID, self.Agent1, 'ens160', capture=True)     # enable capture

        print("Starting test")
        mw.startTest(newSessionID)
        startTime = datetime.datetime.now()     # take current time. Will be used inside HTML report
        
        state = mw.checkSessionState(newSessionID, status='STARTED')
        self.assertEqual(state, True, "The test did not start")  # check if test started

        print(mw.getSessionStatus(newSessionID))

        testId = mw.getTestId(newSessionID)   # get test Id from current session
        
        mw.checkSessionState(newSessionID, status='STOPPED', waitTime=mw.getTestDuration(newSessionID))   # wait until test finishes
        print(mw.getSessionStatus(newSessionID))
        endTime = datetime.datetime.now()   # take time after test ends. Will be used inside HTML report

        # check REST statistics

        print('Extracting REST Stats')
        statsF1Setup = mw.getAllStats(testId, 'Dusimoverview_F1Setup')   # extract all statistics from F1Setup view

        for x in sorted(statsF1Setup):
            print('%s = %s\nMax - %s : %s' % (x,statsF1Setup[x], x, mw.getMaxStat(statsF1Setup[x])))

        # create HTML report based on a list of statistics. The same statistics from above
        listOfStatistics = [
            "Dusimoverview_F1Setup"
            ]
        print("Generating HTML report....")
        mw.createHTMLreport(newSessionID, listOfStatistics, configName, startTime, endTime)

        print("Downloading PDF report.....")
        mw.getPDFreport(newSessionID, configName, startTime)

        print("Downloading CSVs archive...")
        mw.getCSVs(newSessionID, configName, startTime)

        print("Downloading Captures&Logs archive...")
        mw.getCapturesLogs(newSessionID, configName, startTime)

        mw.deleteSession(newSessionID)  # delete session
        mw.getSessionInfo(newSessionID, statusCode=404)


    def test_dusimSa_from_scratch(self):
        # this test will not start because of the incorrect n2 ip addr. This is just an example on how to change option on default configuration
        print( "Test DuSIM...")
        mw = self.newMW(host=self.clusterIP, licenseServer=self.licenseServer, username=self.username, password=self.password)     # create a mw object
        
        newSessionID = mw.newSession(sessionType="DuSimSa")  # start session using default DuSimSa config

    # the following section is used to assign an agent to each simulated node. Skipped this part until line #39 if agents are already assigned to config file
        simulatedNodes = ['ducp', 'duup']   # simulated nodes in the selected config
        agentsDict = {}
        for node in simulatedNodes:   # update all emulated nodes with current agents
            if node == 'ducp':
                agentsDict[node] = [{'agent': self.Agent1, 'F1': 'ens160', 'Kin': 'ens160'}]
            elif node == 'duup':
                agentsDict[node] = [{'agent': self.Agent1, 'F1': 'ens192', 'Kin': 'ens160'}]
            else:
                agentsDict[node] = self.Agent2  # Use second agent for the rest of the nodes
        
        mw.assignAgents(newSessionID, agentsDict)   # assign agents

        # modify ip - topology config DuSmSa in the model.
        # mw.patch_option(sessionID=newSessionID,node="ducp",payload={"localIPAddress":"20.0.10.10"},topology="DuSimSa",api_endpoint="ranges/1/interfaces/f1/connectivitySettings")
        
        # modify mcc. Commented because it will cause the test to not start.
        # mw.patch_option(sessionID=newSessionID,node="ducp",payload={"mcc":"320"},topology="DuSimSa",api_endpoint="ranges/1/nodeSettings")

        print("Starting test")
        mw.startTest(newSessionID)
        
        state = mw.checkSessionState(newSessionID, status='STARTED')
        self.assertEqual(state, True, "The test did not start")  # check if test started

        print(mw.getSessionStatus(newSessionID))

        testId = mw.getTestId(newSessionID)   # get test Id from current session
        
        mw.checkSessionState(newSessionID, status='STOPPED', waitTime=mw.getTestDuration(newSessionID))   # wait until test finishes
        print(mw.getSessionStatus(newSessionID))



if __name__ == '__main__':
    unittest.main()

