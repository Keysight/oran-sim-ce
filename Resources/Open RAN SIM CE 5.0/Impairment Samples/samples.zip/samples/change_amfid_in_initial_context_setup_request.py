import PyLizard

def Vector(data):
    vector = PyLizard.Uint8Vector()
    vector.extend(data)
    return vector

messageChanged = 0

def Callback(*args):
    global messageChanged

    if args[0] == 'Transport::SCTP::Send':
        data = args[1]
        localEndpoint = str(args[2])
        cb = args[3]

        if localEndpoint.startswith('127.0.10.1'): # AMF
            if data[0] == 0x00 and data[1] == 0x0e and messageChanged == 0: # initial context setup request
                print('[Hook] found the first initial context setup request ')
                dataList = list(data)
                dataList[13] = 0x33 # AMF ID
                print('[Hook] Sending the message')
                messageChanged +=1
                cb(Vector(dataList))
    elif args[0] == 'Finalize':
        assert(messageChanged > 0)

PyLizard.SetCallback(Callback)
