import PyLizard
from scapy.all import *
from scapy.contrib.gtp import GTP_U_Header

pktCounter=0 

def Vector(data):
    vector = PyLizard.Uint8Vector()
    vector.extend(data)
    return vector

# Bind the GTPHeader to UDP on port 2152
bind_layers(UDP, GTP_U_Header, dport=2152)

# Helper function to see an example how to access all headers in the packet
def GetAllHeaders(pkt, ipType):
    #print('Raw bytes: %s' % (' '.join(['%02x' % i for i in pkt])))

    if ipType == 0x0800:  # IPv4
        packet = IP(pkt)
    elif ipType == 0x86DD:  # IPv6
        packet = IPv6(pkt)
    else:
        print("Unkonwn IP type: {ipType}")
        return

    #print(packet.show())

    if UDP in packet:
        udpHeader = packet[UDP]

        if udpHeader.dport == 2152:
            gtpHeader = udpHeader[GTP_U_Header]

            if IP in gtpHeader:
                innerIP = gtpHeader[IP]
            elif IPv6 in gtpHeader:
                innerIP = gtpHeader[IPv6]
            else:
                print("Payload is not an IP or IPv6 packet, parsing failed.")
                return

            if UDP in innerIP:
                innerUDPHeader = innerIP[UDP]
            elif TCP in innerIP:
                innerTCPHeader = innerIP[TCP]
            else:
                print("No recognizable payload inside GTP header.")

            # when changing something in inner[*]Header, we need to recompute the checksum by setting innerHeader.chksum = None and calling bytes(innerHeader)

    elif TCP in packet:
        tcpHeader = packet[TCP]
    elif SCTP in packet:
        sctpHeader = packet[SCTP]
    else:
        print("No UDP, TCP, SCTP or GTP found in the packet.")


def Callback(*args):   
    if args[0] == 'IxStack::Packet::Send':
        pkt = bytes(args[1])
        ipType = args[2]
        cb = args[3]
        
        # GetAllHeaders(pkt, ipType)

        if ipType == 0x0800:  # IPv4
            packet = IP(pkt)
        elif ipType == 0x86DD:  # IPv6
            packet = IPv6(pkt)
        else:
            print("Unkonwn IP type: {ipType}")
            return

        # print(packet.show())           

        if UDP in packet:
            udpHeader = packet[UDP]
            # print(udpHeader.show())
            
            if 'GTP-U Header' in udpHeader:
                gtpuHeader = udpHeader['GTP-U Header']
                if 'GTP PDU Session Container' in gtpuHeader:
                    gtpuContainer = gtpuHeader['GTP PDU Session Container']                 
                       
                    if IP in gtpuContainer:     
                        innerIP = gtpuContainer[IP]
                    elif IPv6 in gtpuContainer:
                        innerIP = gtpuContainer[IPv6]
                    else:
                        print("Payload is not an IP or IPv6 packet, parsing failed.")                      
                                           
                    if UDP in innerIP:
                        innerLayer = innerIP[UDP]                         
                        # drop traffic for UE with  innerIP 22.22.22.26
                        if innerIP.src == '22.22.22.26':
                            print("This pkt with UE having IP 22.22.22.26 will be dropped")
                            # print(innerIP.show())
                            cb(Vector(bytes(packet)), True, False)
                            return

                    if TCP in innerIP:
                        innerLayer = innerIP[TCP]                   
                        # drop traffic TCP SYN for innerIP 22.22.22.26
                        if innerIP.src == '22.22.22.26' and innerLayer.flags == 'S':
                            print("This TCP SYN from IP 22.22.22.26 will be dropped")
                            # print(innerIP.show())
                            cb(Vector(bytes(packet)), True, False)
                            return                                                              
            else:
                print("Packet without GTP-u Header")
                # print(udpHeader.show())
                return

        cb(Vector(bytes(packet)), False, False)

PyLizard.SetCallback(Callback)