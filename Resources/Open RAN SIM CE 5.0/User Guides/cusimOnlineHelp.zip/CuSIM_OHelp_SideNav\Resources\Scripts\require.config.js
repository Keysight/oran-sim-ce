require.config({
    urlArgs: 't=638730580293540352'
});