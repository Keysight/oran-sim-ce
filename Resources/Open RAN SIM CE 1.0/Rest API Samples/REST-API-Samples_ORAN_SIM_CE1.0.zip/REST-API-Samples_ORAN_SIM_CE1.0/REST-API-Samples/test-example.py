from base import TestCaseRemote
import unittest
import datetime


class TestMW(TestCaseRemote):

    def __init__(self, *args, **kwargs):
        super(TestMW, self).__init__(*args, **kwargs)
        self.clusterIP = "10.38.158.21"  # UI/MW ip address
        self.Agent1 = "10.38.156.61"  # agent1 ip address used for RAN/SBA
        self.Agent2 = "10.38.158.104"  # agent2 ip address
        self.licenseServer = "10.38.158.11"  # license server
        self.username = 'admin'
        self.password = 'admin'


    def test_full_core(self):
        print( "Test Full Core")
        mw = self.newMW(host=self.clusterIP, licenseServer=self.licenseServer, username=self.username, password=self.password)     # create a mw object
        
        configName = "Full Core Base Config.zip" # config name found in configs folder
        newSessionID = mw.newSession(configArchive=configName)  # start session using the specified config

    # the following section is used to assign an agent to each simulated node. Skipped this part until line #39 if agents are already assigned to config file
        simulatedNodes = ['ran', 'amf', 'nrf', 'ausf', 'udm', 'pcf', 'udr', 'smf', 'upf', 'dn', 'nssf']   # simulated nodes in the selected config
        agentsDict = {}
        for node in simulatedNodes:   # update all emulated nodes with current agents
            if node == 'ran':
                agentsDict[node] = self.Agent1  # Use first agent for RAN node
            elif node == 'dn':
                agentsDict[node] = [{'agent': self.Agent2, 'n6': 'ens160'}]
            else:
                agentsDict[node] = self.Agent2  # Use second agent for the rest of the nodes
        
        mw.assignAgents(newSessionID, agentsDict)   # assign agents

        mw.changeNetworkSettings(newSessionID, self.Agent1, 'ens160', capture=True)     # enable capture

        print("Starting test")
        mw.startTest(newSessionID)
        startTime = datetime.datetime.now()     # take current time. Will be used inside HTML report
        
        state = mw.checkSessionState(newSessionID, status='STARTED')
        self.assertEqual(state, True, "The test did not start")  # check if test started

        print(mw.getSessionStatus(newSessionID))

        testId = mw.getTestId(newSessionID)   # get test Id from current session
        
        mw.checkSessionState(newSessionID, status='STOPPED', waitTime=mw.getTestDuration(newSessionID))   # wait until test finishes
        print(mw.getSessionStatus(newSessionID))
        endTime = datetime.datetime.now()   # take time after test ends. Will be used inside HTML report

        # check REST statistics

        print('Extracting REST Stats')
        statsRegisteredUEs = mw.getAllStats(testId, 'Fullcoreoverview_RegisteredAttachedUE')   # extract all statistics from RegisteredUEs view

        for x in sorted(statsRegisteredUEs):
            print('%s = %s\nMax - %s : %s' % (x,statsRegisteredUEs[x], x, mw.getMaxStat(statsRegisteredUEs[x])))

        statsProcedureRates = mw.getAllStats(testId, 'Fullcorengran_NGRANRegistrationprocedure')   # extract all statistics from ProcedureRates view
        for x in statsProcedureRates:
            print('%s = %s\nAvg Non Zero - %s : %s' % (x, statsProcedureRates[x], x, mw.getAvgNonZeroStat(statsProcedureRates[x])))

        statsPDUSessionEstablishment = mw.getAllStats(testId, 'Fullcorengran_NGRANPDUSessionestablishment')  # extract all statistics from PDUSessionEstablishment view
        for x in statsPDUSessionEstablishment:
            print('%s = %s\nMax - %s : %s' % (x, statsPDUSessionEstablishment[x], x, mw.getMaxStat(statsPDUSessionEstablishment[x])))

        Fullcorengran_NGRANMobilityRegistrationprocedure = mw.getAllStats(testId, 'Fullcorengran_NGRANMobilityRegistrationprocedure')   # extract all statistics from NGRANRegistration view
        for x in Fullcorengran_NGRANMobilityRegistrationprocedure:
            print('%s = %s\nMax - %s : %s' % (x, Fullcorengran_NGRANMobilityRegistrationprocedure[x], x, mw.getMaxStat(Fullcorengran_NGRANMobilityRegistrationprocedure[x])))

        # create HTML report based on a list of statistics. The same statistics from above
        listOfStatistics = [
            "Fullcoreoverview_RegisteredAttachedUE", 
            "Fullcorengran_NGRANRegistrationprocedure", 
            "Fullcorengran_NGRANPDUSessionestablishment", 
            "Fullcorengran_NGRANMobilityRegistrationprocedure"
            ]
        print("Generating HTML report....")
        mw.createHTMLreport(newSessionID, listOfStatistics, configName, startTime, endTime)

        print("Downloading PDF report.....")
        mw.getPDFreport(newSessionID, configName, startTime)

        print("Downloading CSVs archive...")
        mw.getCSVs(newSessionID, configName, startTime)

        print("Downloading Captures&Logs archive...")
        mw.getCapturesLogs(newSessionID, configName, startTime)

        mw.deleteSession(newSessionID)  # delete session
        mw.getSessionInfo(newSessionID, statusCode=404)


    def test_sba_tester_run(self):
        print( "\nTest_sba_tester_run")
        mw = self.newMW(host=self.clusterIP, licenseServer=self.licenseServer, username=self.username, password=self.password)     # create a mw object
        
        configName = "SBA Base Config.zip" # config name found in configs folder
        newSessionID = mw.newSession(configArchive=configName)  # start session using the specified config

        simulatedNodes = ['sbaTester', 'ausf', 'udm', 'pcf', 'udr','nrf','chf','nssf'] # simulated nodes in the selected config
        agentsDict = {}
        for node in simulatedNodes:  # update all emulated nodes with current agents
            if node == 'sbaTester':
                agentsDict[node] = [{'agent': self.Agent1, 'namf': 'ens160', 'nsmf': 'ens160', 'npcf': 'ens160'}]  # Use first agent for SBATester
            else:
                agentsDict[node] = self.Agent2  # Use second agent for the rest of the nodes

        mw.assignAgents(newSessionID, agentsDict)   # assign agents

        print("Starting test")
        mw.startTest(newSessionID)  # start test
        startTime = datetime.datetime.now()     # take current time. Will be used inside HTML report
        
        state = mw.checkSessionState(newSessionID, status='STARTED')
        self.assertEqual(state, True, "The test did not start")  # check if test started
        print(mw.getSessionStatus(newSessionID))

        mw.checkSessionState(newSessionID, status='STOPPED', waitTime=mw.getTestDuration(newSessionID))   # wait until test finishes
        print(mw.getSessionStatus(newSessionID))
        endTime = datetime.datetime.now()   # take time after test ends. Will be used inside HTML report


        testId = mw.getTestId(newSessionID)  # get test Id from current session

        # check REST statistics

        statsTCPconnectionsstatus = mw.getAllStats(testId, 'Sbatestertcpconnections_TCPconnectionsstatus')  # extract all statistics from TCPconnectionsstatus view

        for x in statsTCPconnectionsstatus:
            print('%s = %s\nMax - %s : %s' % (x, statsTCPconnectionsstatus[x], x, mw.getMaxStat(statsTCPconnectionsstatus[x])))

        statsAuthProc = mw.getAllStats(testId, 'Sbatesterudmtester_NausfUEAuthenticationProcedure')   # extract all statistics from NausfUEAuthenticationProcedure view

        for x in statsAuthProc:
            print('%s = %s\nMax - %s : %s' % (x, statsAuthProc[x], x, mw.getMaxStat(statsAuthProc[x])))

        self.assertEqual(max(statsAuthProc['AUSF Authentications TimedOut']), 0)  # check if Auth Timeout stats is 0

        statsUDMTesterProcedureRates = mw.getAllStats(testId, 'Sbatesterudmtester_UDMTesterProcedureRates')   # extract all statistics from UDMTesterProcedureRates view
        for x in statsUDMTesterProcedureRates:
            print('%s = %s\nAvg Non Zero - %s : %s' % (x, statsUDMTesterProcedureRates[x], x, mw.getAvgNonZeroStat(statsUDMTesterProcedureRates[x])))

        NudrResourceURIs = mw.getAllStats(testId, 'Sbatestersbanodes_NudrResourceURIs') 
        print('NudrResourceURIs stats:')
        for x in NudrResourceURIs:
            print('%s = %s' % (x, NudrResourceURIs[x]))

        NausfResourceURIs = mw.getAllStats(testId, 'Sbatestersbanodes_NausfResourceURIs') 
        print('NausfResourceURIs stats:')
        for x in NausfResourceURIs:
            print('%s = %s' % (x, NausfResourceURIs[x]))
        
        NudmResourceURIs = mw.getAllStats(testId, 'Sbatestersbanodes_NudmResourceURIs') 
        print('NudmResourceURIs stats:')
        for x in NudmResourceURIs:
            print('%s = %s' % (x, NudmResourceURIs[x]))

        NpcfResourceURIs = mw.getAllStats(testId, 'Sbatestersbanodes_NpcfResourceURIs') 
        print('NpcfResourceURIs stats:')
        for x in NpcfResourceURIs:
            print('%s = %s' % (x, NpcfResourceURIs[x]))

        
        print("Downloading PDF report.....")
        mw.getPDFreport(newSessionID, configName, startTime)

        print("Downloading CSVs archive...")
        mw.getCSVs(newSessionID, configName, startTime)

        mw.deleteSession(newSessionID)  # delete session
        mw.getSessionInfo(newSessionID, statusCode=404)


    def test_coresim(self):
        print( "Test CoreSim")
        mw = self.newMW(host=self.clusterIP, licenseServer=self.licenseServer, username=self.username, password=self.password)     # create a mw object
        
        configName = "CoreSim Base Config - RAN Enabled.zip" # config name found in configs folder
        newSessionID = mw.newSession(configArchive=configName)  # start session using the specified config

    # the following section is used to assign an agent to each simulated node. Skipped this part until line #191 if agents are already assigned to config file
        agentsDict = {}
        agentsDict['ran'] = self.Agent1  # Use first agent for RAN node
        agentsDict['coreSim'] = [{'agent': self.Agent2, 'n2': 'ens160', 'n3': 'ens160', 'n6': 'none', 's1': 'ens160', 's1u': 'ens160'}]  # Use second agent for coreSim node
        
        mw.assignAgents(newSessionID, agentsDict)   # assign agents

        mw.changeNetworkSettings(newSessionID, self.Agent1, 'ens160', capture=True)     # enable capture

        print("Starting test")
        mw.startTest(newSessionID)
        startTime = datetime.datetime.now()     # take current time. Will be used inside HTML report
        
        state = mw.checkSessionState(newSessionID, status='STARTED')
        self.assertEqual(state, True, "The test did not start")  # check if test started

        print(mw.getSessionStatus(newSessionID))

        testId = mw.getTestId(newSessionID)   # get test Id from current session
        
        mw.checkSessionState(newSessionID, status='STOPPED', waitTime=mw.getTestDuration(newSessionID))   # wait until test finishes
        print(mw.getSessionStatus(newSessionID))
        endTime = datetime.datetime.now()   # take time after test ends. Will be used inside HTML report

        # check REST statistics

        print('Extracting REST Stats')
        statsRegisteredUEs = mw.getAllStats(testId, 'Coresimoverview_RegisteredUE')   # extract all statistics from RegisteredUEs view

        for x in sorted(statsRegisteredUEs):
            print('%s = %s\nMax - %s : %s' % (x,statsRegisteredUEs[x], x, mw.getMaxStat(statsRegisteredUEs[x])))

        statsProcedureRates = mw.getAllStats(testId, 'Coresimngran_NGRANRegistrationprocedure')   # extract all statistics from ProcedureRates view
        for x in statsProcedureRates:
            print('%s = %s\nAvg Non Zero - %s : %s' % (x, statsProcedureRates[x], x, mw.getAvgNonZeroStat(statsProcedureRates[x])))

        Coresimamf_AMFRegistrationprocedure = mw.getAllStats(testId, 'Coresimamf_AMFRegistrationprocedure')  
        for x in Coresimamf_AMFRegistrationprocedure:
            print('%s = %s\nMax - %s : %s' % (x, Coresimamf_AMFRegistrationprocedure[x], x, mw.getMaxStat(Coresimamf_AMFRegistrationprocedure[x])))

        Coresimapplicationtraffic_GTPuPackets_NGRAN = mw.getAllStats(testId, 'Coresimapplicationtraffic_GTPuPackets_NGRAN')  
        for x in Coresimapplicationtraffic_GTPuPackets_NGRAN:
            print('%s = %s\nMax - %s : %s' % (x, Coresimapplicationtraffic_GTPuPackets_NGRAN[x], x, mw.getMaxStat(Coresimapplicationtraffic_GTPuPackets_NGRAN[x])))


        # create HTML report based on a list of statistics. The same statistics from above
        listOfStatistics = [
            "Coresimoverview_RegisteredUE", 
            "Coresimngran_NGRANRegistrationprocedure", 
            "Coresimngran_NGRANPDUSessionestablishment",
            "Coresimamf_AMFRegistrationprocedure",
            "Coresimapplicationtraffic_GTPuPackets_NGRAN",
            "Coresimapplicationtraffic_GTPuPackets_UPF"
            ]
        print("Generating HTML report....")
        mw.createHTMLreport(newSessionID, listOfStatistics, configName, startTime, endTime)


        print("Downloading CSVs archive...")
        mw.getCSVs(newSessionID, configName, startTime)

        print("Downloading Captures&Logs archive...")
        mw.getCapturesLogs(newSessionID, configName, startTime)

        # mw.deleteSession(newSessionID)  # delete session
        # mw.getSessionInfo(newSessionID, statusCode=404)


    def test_full_core_from_scratch(self):
        # this test will not start because of the incorrect n2 ip addr. This is just an example on how to change option on default configuration
        print( "Test Full Core")
        mw = self.newMW(host=self.clusterIP, licenseServer=self.licenseServer, username=self.username, password=self.password)     # create a mw object
        
        newSessionID = mw.newSession(sessionType="fullCore")  # start session using default fullcore config

    # the following section is used to assign an agent to each simulated node. Skipped this part until line #39 if agents are already assigned to config file
        simulatedNodes = ['ran', 'amf', 'nrf', 'ausf', 'udm', 'pcf', 'udr', 'smf', 'upf', 'dn', 'nssf']   # simulated nodes in the selected config
        agentsDict = {}
        for node in simulatedNodes:   # update all emulated nodes with current agents
            if node == 'ran':
                agentsDict[node] = self.Agent1  # Use first agent for RAN node
            elif node == 'dn':
                agentsDict[node] = [{'agent': self.Agent1, 'n6': 'ens160'}]
            else:
                agentsDict[node] = self.Agent1 
        
        mw.assignAgents(newSessionID, agentsDict)   # assign agents

        # modify the ip on n2 - topology config e fullcore in the model. Commented because it will cause the test to not start.
        # mw.patch_option(sessionID=newSessionID,node="ran",payload={"localIPAddress":"20.0.10.10"},topology="config",api_endpoint="ranges/1/interfaces/n2/connectivitySettings")
        
        # modify mcc. Commented because it will cause the test to not start.
        # mw.patch_option(sessionID=newSessionID,node="ran",payload={"mcc":"320"},topology="config",api_endpoint="ranges/1/nodeSettings")

        print("Starting test")
        mw.startTest(newSessionID)
        
        state = mw.checkSessionState(newSessionID, status='STARTED')
        self.assertEqual(state, True, "The test did not start")  # check if test started

        print(mw.getSessionStatus(newSessionID))

        testId = mw.getTestId(newSessionID)   # get test Id from current session
        
        mw.checkSessionState(newSessionID, status='STOPPED', waitTime=mw.getTestDuration(newSessionID))   # wait until test finishes
        print(mw.getSessionStatus(newSessionID))



if __name__ == '__main__':
    unittest.main()
