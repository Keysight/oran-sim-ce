var xmlAliasData = "";
xmlAliasData += '<?xml version=\"1.0\" encoding=\"utf-8\"?>';
xmlAliasData += '<CatapultAliasFile conditions=\"ImportConditions.ProjectTemplatesFiles\">';
xmlAliasData += '    <!-- saved from url=(0016)http://localhost -->';
xmlAliasData += '</CatapultAliasFile>';
MadCap.Utilities.Xhr._FilePathToXmlStringMap.Add('Alias', xmlAliasData);
