require.config({
    urlArgs: 't=638998666204267727'
});